import com.hospital.dao.MedicationDAO;
import com.hospital.util.AuditLogger;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/MedicationServlet")
public class MedicationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        if ("create".equals(action)) {
            String name = request.getParameter("name");
            String genericName = request.getParameter("genericName");
            String strength = request.getParameter("strength");
            String unit = request.getParameter("unit");
            String manufacturer = request.getParameter("manufacturer");
            double minSingleDose = Double.parseDouble(request.getParameter("minSingleDose") != null ? request.getParameter("minSingleDose") : "0");
            double maxSingleDose = Double.parseDouble(request.getParameter("maxSingleDose"));
            double maxDailyDose = Double.parseDouble(request.getParameter("maxDailyDose") != null ? request.getParameter("maxDailyDose") : "0");
            String sideEffects = request.getParameter("sideEffects");
            String contraindications = request.getParameter("contraindications");

            int medicationId = MedicationDAO.createMedication(name, genericName, strength, unit, 
                                                             manufacturer, maxDailyDose, minSingleDose, 
                                                             maxSingleDose, sideEffects, contraindications);
            
            if (medicationId > 0) {
                AuditLogger.logAction(userId, "CREATE", "medication", medicationId, "", name);
                response.sendRedirect("medications.jsp?success=created");
            } else {
                response.sendRedirect("medications.jsp?error=failed");
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        if ("delete".equals(action)) {
            String medicationIdStr = request.getParameter("medicationId");
            if (medicationIdStr != null) {
                int medicationId = Integer.parseInt(medicationIdStr);
                MedicationDAO.Medication medication = MedicationDAO.getMedicationById(medicationId);
                
                if (MedicationDAO.deleteMedication(medicationId)) {
                    AuditLogger.logAction(userId, "DELETE", "medication", medicationId, medication.name, "");
                    response.sendRedirect("medications.jsp?success=deleted");
                } else {
                    response.sendRedirect("medications.jsp?error=failed");
                }
            }
        }
    }
}
