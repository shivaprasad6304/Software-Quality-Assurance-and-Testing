import com.hospital.dao.UserDAO;
import com.hospital.dao.PatientDAO;
import com.hospital.dao.DoctorDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirm_password");
        String role = request.getParameter("role");

        // Validation
        if (username == null || username.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            password == null || password.trim().isEmpty() ||
            role == null || role.trim().isEmpty()) {
            response.sendRedirect("register.jsp?error=invalid");
            return;
        }

        if (!password.equals(confirmPassword)) {
            response.sendRedirect("register.jsp?error=invalid");
            return;
        }

        if (password.length() < 6) {
            response.sendRedirect("register.jsp?error=invalid");
            return;
        }

        // Register user
        boolean userCreated = UserDAO.registerUser(username, password, email, role);

        if (userCreated) {
            // If patient, create patient record
            if ("patient".equals(role)) {
                UserDAO.User user = UserDAO.loginUser(username, password);
                if (user != null) {
                    PatientDAO.createPatient(user.userId, "FirstName", "LastName", null, 
                                            null, null, null, null, null, null);
                }
            }
            // If doctor, create doctor record
            else if ("doctor".equals(role)) {
                UserDAO.User user = UserDAO.loginUser(username, password);
                if (user != null) {
                    DoctorDAO.createDoctor(user.userId, "FirstName", "LastName", 
                                          null, null, null, email);
                }
            }

            response.sendRedirect("login.jsp?success=registered");
        } else {
            response.sendRedirect("register.jsp?error=username_exists");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("register.jsp");
    }
}
