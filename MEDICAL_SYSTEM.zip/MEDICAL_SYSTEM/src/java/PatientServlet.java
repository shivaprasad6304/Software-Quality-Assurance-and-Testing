import com.hospital.dao.PatientDAO;
import com.hospital.util.AuditLogger;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/PatientServlet")
public class PatientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        // Validate session
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        if ("create".equals(action)) {
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String dob = request.getParameter("dob");
            String gender = request.getParameter("gender");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String bloodGroup = request.getParameter("bloodGroup");
            String allergies = request.getParameter("allergies");
            String medicalHistory = request.getParameter("medicalHistory");

            // Validate required fields
            if (firstName == null || firstName.trim().isEmpty() ||
                lastName == null || lastName.trim().isEmpty()) {
                response.sendRedirect("patients.jsp?error=required_fields");
                return;
            }

            try {
                int patientId = PatientDAO.createPatient(0, firstName, lastName, dob, gender, phone, address, 
                                                        bloodGroup, allergies, medicalHistory);
                
                if (patientId > 0) {
                    AuditLogger.logAction(userId, "CREATE", "patient", patientId, "", firstName + " " + lastName);
                    response.sendRedirect("patients.jsp?success=created");
                } else {
                    response.sendRedirect("patients.jsp?error=failed");
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("patients.jsp?error=exception");
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        // Validate session
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        if ("delete".equals(action)) {
            String patientIdStr = request.getParameter("patientId");
            
            if (patientIdStr == null || patientIdStr.trim().isEmpty()) {
                response.sendRedirect("patients.jsp?error=invalid_id");
                return;
            }

            try {
                int patientId = Integer.parseInt(patientIdStr);
                PatientDAO.Patient patient = PatientDAO.getPatientById(patientId);
                
                if (patient == null) {
                    response.sendRedirect("patients.jsp?error=not_found");
                    return;
                }

                if (PatientDAO.deletePatient(patientId)) {
                    AuditLogger.logAction(userId, "DELETE", "patient", patientId, 
                                        patient.firstName + " " + patient.lastName, "");
                    response.sendRedirect("patients.jsp?success=deleted");
                } else {
                    response.sendRedirect("patients.jsp?error=failed");
                }
            } catch (NumberFormatException e) {
                response.sendRedirect("patients.jsp?error=invalid_id");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("patients.jsp?error=exception");
            }
        }
    }
}
