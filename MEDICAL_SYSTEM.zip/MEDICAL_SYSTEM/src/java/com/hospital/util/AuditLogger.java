package com.hospital.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AuditLogger {

    public static void logAction(int userId, String action, String entityType, 
                                 int entityId, String oldValue, String newValue) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO audit_trail (user_id, action, entity_type, entity_id, old_value, new_value) " +
                          "VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, userId);
            pstmt.setString(2, action);
            pstmt.setString(3, entityType);
            pstmt.setInt(4, entityId);
            pstmt.setString(5, oldValue);
            pstmt.setString(6, newValue);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }

    public static void createAlert(int prescriptionDetailId, String alertType, String severity, String message) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO alerts (prescription_detail_id, alert_type, severity, message) " +
                          "VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, prescriptionDetailId);
            pstmt.setString(2, alertType);
            pstmt.setString(3, severity);
            pstmt.setString(4, message);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }

    public static void recordMetric(String metricType, int totalPrescriptions, int validatedPrescriptions,
                                   int rejectedPrescriptions, int alertsGenerated, int alertsResolved,
                                   int drugInteractionsDetected) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO metrics (metric_type, metric_date, total_prescriptions, " +
                          "validated_prescriptions, rejected_prescriptions, alerts_generated, " +
                          "alerts_resolved, drug_interactions_detected) " +
                          "VALUES (?, CURDATE(), ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, metricType);
            pstmt.setInt(2, totalPrescriptions);
            pstmt.setInt(3, validatedPrescriptions);
            pstmt.setInt(4, rejectedPrescriptions);
            pstmt.setInt(5, alertsGenerated);
            pstmt.setInt(6, alertsResolved);
            pstmt.setInt(7, drugInteractionsDetected);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }
}
