package com.hospital.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicationValidator {

    public static class ValidationResult {
        public boolean isValid;
        public String message;
        public String severity;

        public ValidationResult(boolean isValid, String message, String severity) {
            this.isValid = isValid;
            this.message = message;
            this.severity = severity;
        }
    }

    public static ValidationResult validateDosage(int medicationId, double dosage, String dosageUnit) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT min_single_dose, max_single_dose, max_daily_dose FROM medications WHERE medication_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, medicationId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                double minDose = rs.getDouble("min_single_dose");
                double maxSingleDose = rs.getDouble("max_single_dose");
                double maxDailyDose = rs.getDouble("max_daily_dose");

                if (dosage < minDose) {
                    return new ValidationResult(false, 
                        "Dosage " + dosage + " is below minimum recommended dose of " + minDose, 
                        "warning");
                }

                if (dosage > maxSingleDose) {
                    return new ValidationResult(false, 
                        "Dosage " + dosage + " exceeds maximum single dose of " + maxSingleDose, 
                        "severe");
                }

                return new ValidationResult(true, "Dosage is within safe limits", "none");
            }

            return new ValidationResult(false, "Medication not found", "error");

        } catch (SQLException e) {
            return new ValidationResult(false, "Database error: " + e.getMessage(), "error");
        } finally {
            closeResources(conn, pstmt, rs);
        }
    }

    public static List<String> checkDrugInteractions(int prescriptionId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<String> interactions = new ArrayList<>();

        try {
            conn = DBConnection.getConnection();

            // Get all medications in the prescription
            String getMedsQuery = "SELECT medication_id FROM prescription_details WHERE prescription_id = ?";
            pstmt = conn.prepareStatement(getMedsQuery);
            pstmt.setInt(1, prescriptionId);
            rs = pstmt.executeQuery();

            List<Integer> medicationIds = new ArrayList<>();
            while (rs.next()) {
                medicationIds.add(rs.getInt("medication_id"));
            }
            rs.close();
            pstmt.close();

            // Check interactions between medications
            for (int i = 0; i < medicationIds.size(); i++) {
                for (int j = i + 1; j < medicationIds.size(); j++) {
                    String interactionQuery = 
                        "SELECT description, severity FROM drug_interactions WHERE " +
                        "(medication_id_1 = ? AND medication_id_2 = ?) OR " +
                        "(medication_id_1 = ? AND medication_id_2 = ?)";
                    
                    pstmt = conn.prepareStatement(interactionQuery);
                    pstmt.setInt(1, medicationIds.get(i));
                    pstmt.setInt(2, medicationIds.get(j));
                    pstmt.setInt(3, medicationIds.get(j));
                    pstmt.setInt(4, medicationIds.get(i));
                    
                    rs = pstmt.executeQuery();
                    if (rs.next()) {
                        String description = rs.getString("description");
                        String severity = rs.getString("severity");
                        interactions.add("[" + severity.toUpperCase() + "] " + description);
                    }
                    rs.close();
                    pstmt.close();
                }
            }

        } catch (SQLException e) {
            interactions.add("Error checking interactions: " + e.getMessage());
        } finally {
            closeResources(conn, pstmt, rs);
        }

        return interactions;
    }

    public static ValidationResult checkPatientAllergies(int patientId, int medicationId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            
            String query = "SELECT allergies FROM patients WHERE patient_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, patientId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String allergies = rs.getString("allergies");
                if (allergies != null && !allergies.isEmpty()) {
                    // Check if medication name is in allergies (simple check)
                    String medQuery = "SELECT name FROM medications WHERE medication_id = ?";
                    pstmt = conn.prepareStatement(medQuery);
                    pstmt.setInt(1, medicationId);
                    ResultSet medRs = pstmt.executeQuery();
                    
                    if (medRs.next()) {
                        String medName = medRs.getString("name");
                        if (allergies.toLowerCase().contains(medName.toLowerCase())) {
                            return new ValidationResult(false, 
                                "Patient is allergic to this medication", 
                                "severe");
                        }
                    }
                    medRs.close();
                }
            }

            return new ValidationResult(true, "No allergies found", "none");

        } catch (SQLException e) {
            return new ValidationResult(false, "Error checking allergies: " + e.getMessage(), "error");
        } finally {
            closeResources(conn, pstmt, rs);
        }
    }

    private static void closeResources(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        DBConnection.closeConnection(conn);
    }
}
