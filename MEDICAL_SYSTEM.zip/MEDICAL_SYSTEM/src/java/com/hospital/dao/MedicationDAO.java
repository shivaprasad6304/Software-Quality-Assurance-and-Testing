package com.hospital.dao;

import com.hospital.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicationDAO {

    public static class Medication {
        public int medicationId;
        public String name;
        public String genericName;
        public String strength;
        public String unit;
        public String manufacturer;
        public double maxDailyDose;
        public double minSingleDose;
        public double maxSingleDose;
        public String sideEffects;
        public String contraindications;
        public boolean isActive;

        public Medication(int medicationId, String name, String genericName, String strength, String unit,
                         String manufacturer, double maxDailyDose, double minSingleDose, double maxSingleDose,
                         String sideEffects, String contraindications, boolean isActive) {
            this.medicationId = medicationId;
            this.name = name;
            this.genericName = genericName;
            this.strength = strength;
            this.unit = unit;
            this.manufacturer = manufacturer;
            this.maxDailyDose = maxDailyDose;
            this.minSingleDose = minSingleDose;
            this.maxSingleDose = maxSingleDose;
            this.sideEffects = sideEffects;
            this.contraindications = contraindications;
            this.isActive = isActive;
        }
    }

    public static int createMedication(String name, String genericName, String strength, String unit,
                                      String manufacturer, double maxDailyDose, double minSingleDose,
                                      double maxSingleDose, String sideEffects, String contraindications) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO medications (name, generic_name, strength, unit, manufacturer, " +
                          "max_daily_dose, min_single_dose, max_single_dose, side_effects, contraindications, is_active) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE)";
            pstmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, name);
            pstmt.setString(2, genericName);
            pstmt.setString(3, strength);
            pstmt.setString(4, unit);
            pstmt.setString(5, manufacturer);
            pstmt.setDouble(6, maxDailyDose);
            pstmt.setDouble(7, minSingleDose);
            pstmt.setDouble(8, maxSingleDose);
            pstmt.setString(9, sideEffects);
            pstmt.setString(10, contraindications);
            
            pstmt.executeUpdate();
            rs = pstmt.getGeneratedKeys();
            
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return -1;
    }

    public static Medication getMedicationById(int medicationId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM medications WHERE medication_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, medicationId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Medication(
                    rs.getInt("medication_id"),
                    rs.getString("name"),
                    rs.getString("generic_name"),
                    rs.getString("strength"),
                    rs.getString("unit"),
                    rs.getString("manufacturer"),
                    rs.getDouble("max_daily_dose"),
                    rs.getDouble("min_single_dose"),
                    rs.getDouble("max_single_dose"),
                    rs.getString("side_effects"),
                    rs.getString("contraindications"),
                    rs.getBoolean("is_active")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return null;
    }

    public static List<Medication> getAllMedications() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Medication> medications = new ArrayList<>();

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM medications WHERE is_active = TRUE ORDER BY name ASC";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                medications.add(new Medication(
                    rs.getInt("medication_id"),
                    rs.getString("name"),
                    rs.getString("generic_name"),
                    rs.getString("strength"),
                    rs.getString("unit"),
                    rs.getString("manufacturer"),
                    rs.getDouble("max_daily_dose"),
                    rs.getDouble("min_single_dose"),
                    rs.getDouble("max_single_dose"),
                    rs.getString("side_effects"),
                    rs.getString("contraindications"),
                    rs.getBoolean("is_active")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return medications;
    }

    public static boolean updateMedication(int medicationId, String name, String genericName, String strength,
                                          String unit, String manufacturer, double maxDailyDose,
                                          double minSingleDose, double maxSingleDose, String sideEffects,
                                          String contraindications) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "UPDATE medications SET name = ?, generic_name = ?, strength = ?, unit = ?, " +
                          "manufacturer = ?, max_daily_dose = ?, min_single_dose = ?, max_single_dose = ?, " +
                          "side_effects = ?, contraindications = ? WHERE medication_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, genericName);
            pstmt.setString(3, strength);
            pstmt.setString(4, unit);
            pstmt.setString(5, manufacturer);
            pstmt.setDouble(6, maxDailyDose);
            pstmt.setDouble(7, minSingleDose);
            pstmt.setDouble(8, maxSingleDose);
            pstmt.setString(9, sideEffects);
            pstmt.setString(10, contraindications);
            pstmt.setInt(11, medicationId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }

    public static boolean deleteMedication(int medicationId) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "UPDATE medications SET is_active = FALSE WHERE medication_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, medicationId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }
}
