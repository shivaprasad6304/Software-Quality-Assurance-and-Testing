package com.hospital.dao;

import com.hospital.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrescriptionDAO {

    public static class Prescription {
        public int prescriptionId;
        public int patientId;
        public int doctorId;
        public String createdDate;
        public String notes;
        public String status;

        public Prescription(int prescriptionId, int patientId, int doctorId, String createdDate, String notes, String status) {
            this.prescriptionId = prescriptionId;
            this.patientId = patientId;
            this.doctorId = doctorId;
            this.createdDate = createdDate;
            this.notes = notes;
            this.status = status;
        }
    }

    public static class PrescriptionDetail {
        public int detailId;
        public int prescriptionId;
        public int medicationId;
        public double dosage;
        public String dosageUnit;
        public String frequency;
        public int durationDays;
        public String specialInstructions;
        public String validationStatus;
        public String validationMessage;
        public boolean isValidated;

        public PrescriptionDetail(int detailId, int prescriptionId, int medicationId, double dosage,
                                 String dosageUnit, String frequency, int durationDays, String specialInstructions,
                                 String validationStatus, String validationMessage, boolean isValidated) {
            this.detailId = detailId;
            this.prescriptionId = prescriptionId;
            this.medicationId = medicationId;
            this.dosage = dosage;
            this.dosageUnit = dosageUnit;
            this.frequency = frequency;
            this.durationDays = durationDays;
            this.specialInstructions = specialInstructions;
            this.validationStatus = validationStatus;
            this.validationMessage = validationMessage;
            this.isValidated = isValidated;
        }
    }

    public static int createPrescription(int patientId, int doctorId, String notes) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO prescriptions (patient_id, doctor_id, notes, status) " +
                          "VALUES (?, ?, ?, 'active')";
            pstmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, patientId);
            pstmt.setInt(2, doctorId);
            pstmt.setString(3, notes);
            
            pstmt.executeUpdate();
            rs = pstmt.getGeneratedKeys();
            
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return -1;
    }

    public static int addPrescriptionDetail(int prescriptionId, int medicationId, double dosage,
                                           String dosageUnit, String frequency, int durationDays,
                                           String specialInstructions) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO prescription_details (prescription_id, medication_id, dosage, dosage_unit, " +
                          "frequency, duration_days, special_instructions, validation_status, is_validated) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', FALSE)";
            pstmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, prescriptionId);
            pstmt.setInt(2, medicationId);
            pstmt.setDouble(3, dosage);
            pstmt.setString(4, dosageUnit);
            pstmt.setString(5, frequency);
            pstmt.setInt(6, durationDays);
            pstmt.setString(7, specialInstructions);
            
            pstmt.executeUpdate();
            rs = pstmt.getGeneratedKeys();
            
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return -1;
    }

    public static Prescription getPrescriptionById(int prescriptionId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM prescriptions WHERE prescription_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, prescriptionId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Prescription(
                    rs.getInt("prescription_id"),
                    rs.getInt("patient_id"),
                    rs.getInt("doctor_id"),
                    rs.getString("created_date"),
                    rs.getString("notes"),
                    rs.getString("status")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return null;
    }

    public static List<Prescription> getPrescriptionsByPatientId(int patientId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Prescription> prescriptions = new ArrayList<>();

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM prescriptions WHERE patient_id = ? ORDER BY created_date DESC";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, patientId);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                prescriptions.add(new Prescription(
                    rs.getInt("prescription_id"),
                    rs.getInt("patient_id"),
                    rs.getInt("doctor_id"),
                    rs.getString("created_date"),
                    rs.getString("notes"),
                    rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return prescriptions;
    }

    public static List<PrescriptionDetail> getPrescriptionDetails(int prescriptionId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<PrescriptionDetail> details = new ArrayList<>();

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM prescription_details WHERE prescription_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, prescriptionId);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                details.add(new PrescriptionDetail(
                    rs.getInt("detail_id"),
                    rs.getInt("prescription_id"),
                    rs.getInt("medication_id"),
                    rs.getDouble("dosage"),
                    rs.getString("dosage_unit"),
                    rs.getString("frequency"),
                    rs.getInt("duration_days"),
                    rs.getString("special_instructions"),
                    rs.getString("validation_status"),
                    rs.getString("validation_message"),
                    rs.getBoolean("is_validated")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return details;
    }

    public static boolean updatePrescriptionDetailValidation(int detailId, String validationStatus, String validationMessage, boolean isValidated) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "UPDATE prescription_details SET validation_status = ?, validation_message = ?, is_validated = ? WHERE detail_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, validationStatus);
            pstmt.setString(2, validationMessage);
            pstmt.setBoolean(3, isValidated);
            pstmt.setInt(4, detailId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }

    public static List<Prescription> getAllPrescriptions() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Prescription> prescriptions = new ArrayList<>();

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM prescriptions ORDER BY created_date DESC";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                prescriptions.add(new Prescription(
                    rs.getInt("prescription_id"),
                    rs.getInt("patient_id"),
                    rs.getInt("doctor_id"),
                    rs.getString("created_date"),
                    rs.getString("notes"),
                    rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return prescriptions;
    }

    public static boolean deletePrescription(int prescriptionId) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "DELETE FROM prescriptions WHERE prescription_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, prescriptionId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }
}
