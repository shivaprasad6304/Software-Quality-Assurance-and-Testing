package com.hospital.dao;

import com.hospital.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO {

    public static class Doctor {
        public int doctorId;
        public int userId;
        public String firstName;
        public String lastName;
        public String specialization;
        public String licenseNumber;
        public String phone;
        public String email;

        public Doctor(int doctorId, int userId, String firstName, String lastName, String specialization,
                     String licenseNumber, String phone, String email) {
            this.doctorId = doctorId;
            this.userId = userId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.specialization = specialization;
            this.licenseNumber = licenseNumber;
            this.phone = phone;
            this.email = email;
        }
    }

    public static int createDoctor(int userId, String firstName, String lastName, String specialization,
                                  String licenseNumber, String phone, String email) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO doctors (user_id, first_name, last_name, specialization, license_number, phone, email) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, userId);
            pstmt.setString(2, firstName);
            pstmt.setString(3, lastName);
            pstmt.setString(4, specialization);
            pstmt.setString(5, licenseNumber);
            pstmt.setString(6, phone);
            pstmt.setString(7, email);
            
            pstmt.executeUpdate();
            rs = pstmt.getGeneratedKeys();
            
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return -1;
    }

    public static Doctor getDoctorById(int doctorId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM doctors WHERE doctor_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, doctorId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Doctor(
                    rs.getInt("doctor_id"),
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("specialization"),
                    rs.getString("license_number"),
                    rs.getString("phone"),
                    rs.getString("email")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return null;
    }

    public static Doctor getDoctorByUserId(int userId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM doctors WHERE user_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Doctor(
                    rs.getInt("doctor_id"),
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("specialization"),
                    rs.getString("license_number"),
                    rs.getString("phone"),
                    rs.getString("email")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return null;
    }

    public static List<Doctor> getAllDoctors() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Doctor> doctors = new ArrayList<>();

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM doctors ORDER BY first_name ASC";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                doctors.add(new Doctor(
                    rs.getInt("doctor_id"),
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("specialization"),
                    rs.getString("license_number"),
                    rs.getString("phone"),
                    rs.getString("email")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return doctors;
    }

    public static boolean updateDoctor(int doctorId, String firstName, String lastName, String specialization,
                                      String licenseNumber, String phone, String email) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "UPDATE doctors SET first_name = ?, last_name = ?, specialization = ?, " +
                          "license_number = ?, phone = ?, email = ? WHERE doctor_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, specialization);
            pstmt.setString(4, licenseNumber);
            pstmt.setString(5, phone);
            pstmt.setString(6, email);
            pstmt.setInt(7, doctorId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }

    public static boolean deleteDoctor(int doctorId) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "DELETE FROM doctors WHERE doctor_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, doctorId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }
}
