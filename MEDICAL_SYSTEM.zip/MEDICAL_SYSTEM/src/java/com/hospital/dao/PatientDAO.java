package com.hospital.dao;

import com.hospital.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    public static class Patient {
        public int patientId;
        public int userId;
        public String firstName;
        public String lastName;
        public String dateOfBirth;
        public String gender;
        public String phone;
        public String address;
        public String bloodGroup;
        public String allergies;
        public String medicalHistory;

        public Patient(int patientId, int userId, String firstName, String lastName, String dateOfBirth,
                      String gender, String phone, String address, String bloodGroup, String allergies, String medicalHistory) {
            this.patientId = patientId;
            this.userId = userId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.dateOfBirth = dateOfBirth;
            this.gender = gender;
            this.phone = phone;
            this.address = address;
            this.bloodGroup = bloodGroup;
            this.allergies = allergies;
            this.medicalHistory = medicalHistory;
        }
    }

    public static int createPatient(int userId, String firstName, String lastName, String dateOfBirth,
                                   String gender, String phone, String address, String bloodGroup,
                                   String allergies, String medicalHistory) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "INSERT INTO patients (user_id, first_name, last_name, date_of_birth, gender, phone, address, blood_group, allergies, medical_history) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, userId);
            pstmt.setString(2, firstName);
            pstmt.setString(3, lastName);
            pstmt.setString(4, dateOfBirth);
            pstmt.setString(5, gender);
            pstmt.setString(6, phone);
            pstmt.setString(7, address);
            pstmt.setString(8, bloodGroup);
            pstmt.setString(9, allergies);
            pstmt.setString(10, medicalHistory);
            
            pstmt.executeUpdate();
            rs = pstmt.getGeneratedKeys();
            
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return -1;
    }

    public static Patient getPatientById(int patientId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM patients WHERE patient_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, patientId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Patient(
                    rs.getInt("patient_id"),
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("date_of_birth"),
                    rs.getString("gender"),
                    rs.getString("phone"),
                    rs.getString("address"),
                    rs.getString("blood_group"),
                    rs.getString("allergies"),
                    rs.getString("medical_history")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return null;
    }

    public static Patient getPatientByUserId(int userId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM patients WHERE user_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Patient(
                    rs.getInt("patient_id"),
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("date_of_birth"),
                    rs.getString("gender"),
                    rs.getString("phone"),
                    rs.getString("address"),
                    rs.getString("blood_group"),
                    rs.getString("allergies"),
                    rs.getString("medical_history")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return null;
    }

    public static List<Patient> getAllPatients() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Patient> patients = new ArrayList<>();

        try {
            conn = DBConnection.getConnection();
            String query = "SELECT * FROM patients ORDER BY first_name ASC";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                patients.add(new Patient(
                    rs.getInt("patient_id"),
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("date_of_birth"),
                    rs.getString("gender"),
                    rs.getString("phone"),
                    rs.getString("address"),
                    rs.getString("blood_group"),
                    rs.getString("allergies"),
                    rs.getString("medical_history")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }

        return patients;
    }

    public static boolean updatePatient(int patientId, String firstName, String lastName, String dateOfBirth,
                                       String gender, String phone, String address, String bloodGroup,
                                       String allergies, String medicalHistory) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "UPDATE patients SET first_name = ?, last_name = ?, date_of_birth = ?, gender = ?, " +
                          "phone = ?, address = ?, blood_group = ?, allergies = ?, medical_history = ? WHERE patient_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, dateOfBirth);
            pstmt.setString(4, gender);
            pstmt.setString(5, phone);
            pstmt.setString(6, address);
            pstmt.setString(7, bloodGroup);
            pstmt.setString(8, allergies);
            pstmt.setString(9, medicalHistory);
            pstmt.setInt(10, patientId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }

    public static boolean deletePatient(int patientId) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBConnection.getConnection();
            String query = "DELETE FROM patients WHERE patient_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, patientId);
            
            int result = pstmt.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DBConnection.closeConnection(conn);
        }
    }
}
