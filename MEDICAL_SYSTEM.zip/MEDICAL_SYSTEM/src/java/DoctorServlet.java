import com.hospital.dao.DoctorDAO;
import com.hospital.util.AuditLogger;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DoctorServlet")
public class DoctorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        if ("create".equals(action)) {
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String specialization = request.getParameter("specialization");
            String licenseNumber = request.getParameter("licenseNumber");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");

            int doctorId = DoctorDAO.createDoctor(0, firstName, lastName, specialization, licenseNumber, phone, email);
            
            if (doctorId > 0) {
                AuditLogger.logAction(userId, "CREATE", "doctor", doctorId, "", firstName + " " + lastName);
                response.sendRedirect("doctors.jsp?success=created");
            } else {
                response.sendRedirect("doctors.jsp?error=failed");
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        if ("delete".equals(action)) {
            String doctorIdStr = request.getParameter("doctorId");
            if (doctorIdStr != null) {
                int doctorId = Integer.parseInt(doctorIdStr);
                DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(doctorId);
                
                if (DoctorDAO.deleteDoctor(doctorId)) {
                    AuditLogger.logAction(userId, "DELETE", "doctor", doctorId, doctor.firstName + " " + doctor.lastName, "");
                    response.sendRedirect("doctors.jsp?success=deleted");
                } else {
                    response.sendRedirect("doctors.jsp?error=failed");
                }
            }
        }
    }
}
