import com.hospital.dao.PrescriptionDAO;
import com.hospital.util.AuditLogger;
import com.hospital.util.MedicationValidator;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/PrescriptionServlet")
public class PrescriptionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        if ("create".equals(action)) {
            String patientIdStr = request.getParameter("patientId");
            String doctorIdStr = request.getParameter("doctorId");
            String notes = request.getParameter("notes");
            
            String[] medicationIds = request.getParameterValues("medicationId[]");
            String[] dosages = request.getParameterValues("dosage[]");
            String[] dosageUnits = request.getParameterValues("dosageUnit[]");
            String[] frequencies = request.getParameterValues("frequency[]");
            String[] durations = request.getParameterValues("duration[]");
            String[] specialInstructions = request.getParameterValues("specialInstructions[]");

            int patientId = Integer.parseInt(patientIdStr);
            int doctorId = Integer.parseInt(doctorIdStr);

            // Create prescription
            int prescriptionId = PrescriptionDAO.createPrescription(patientId, doctorId, notes);

            if (prescriptionId > 0) {
                int alertCount = 0;
                int validatedCount = 0;
                int rejectedCount = 0;
                List<String> interactions = MedicationValidator.checkDrugInteractions(prescriptionId);

                // Add medications and validate
                for (int i = 0; i < medicationIds.length; i++) {
                    int medicationId = Integer.parseInt(medicationIds[i]);
                    double dosage = Double.parseDouble(dosages[i]);
                    String dosageUnit = dosageUnits[i];
                    String frequency = frequencies[i];
                    int duration = Integer.parseInt(durations[i]);
                    String instruction = specialInstructions[i];

                    // Add prescription detail
                    int detailId = PrescriptionDAO.addPrescriptionDetail(prescriptionId, medicationId, 
                                                                         dosage, dosageUnit, frequency, 
                                                                         duration, instruction);

                    // Validate dosage
                    MedicationValidator.ValidationResult dosageValidation = 
                        MedicationValidator.validateDosage(medicationId, dosage, dosageUnit);

                    // Validate allergies
                    MedicationValidator.ValidationResult allergyValidation = 
                        MedicationValidator.checkPatientAllergies(patientId, medicationId);

                    String validationStatus = "validated";
                    String validationMessage = "All checks passed";

                    if (!dosageValidation.isValid) {
                        validationStatus = "rejected";
                        validationMessage = dosageValidation.message;
                        rejectedCount++;
                        alertCount++;
                        AuditLogger.createAlert(detailId, "dosage_error", dosageValidation.severity, dosageValidation.message);
                    } else if (!allergyValidation.isValid) {
                        validationStatus = "rejected";
                        validationMessage = allergyValidation.message;
                        rejectedCount++;
                        alertCount++;
                        AuditLogger.createAlert(detailId, "allergies", allergyValidation.severity, allergyValidation.message);
                    } else {
                        validatedCount++;
                    }

                    // Update validation status
                    PrescriptionDAO.updatePrescriptionDetailValidation(detailId, validationStatus, validationMessage, true);
                }

                // Check for drug interactions
                if (!interactions.isEmpty()) {
                    alertCount += interactions.size();
                    for (String interaction : interactions) {
                        AuditLogger.createAlert(0, "drug_interaction", "warning", interaction);
                    }
                }

                // Log the action
                AuditLogger.logAction(userId, "CREATE", "prescription", prescriptionId, "", 
                                    "Patient ID: " + patientId + ", Medications: " + medicationIds.length);

                // Record metrics
                AuditLogger.recordMetric("DAILY", 1, validatedCount, rejectedCount, alertCount, 0, interactions.size());

                response.sendRedirect("my_prescriptions.jsp?success=created&prescriptionId=" + prescriptionId);
            } else {
                response.sendRedirect("create_prescription.jsp?error=failed");
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        if ("delete".equals(action)) {
            String prescriptionIdStr = request.getParameter("prescriptionId");
            if (prescriptionIdStr != null) {
                int prescriptionId = Integer.parseInt(prescriptionIdStr);
                
                if (PrescriptionDAO.deletePrescription(prescriptionId)) {
                    AuditLogger.logAction(userId, "DELETE", "prescription", prescriptionId, "", "");
                    response.sendRedirect("prescriptions.jsp?success=deleted");
                } else {
                    response.sendRedirect("prescriptions.jsp?error=failed");
                }
            }
        }
    }
}
