import com.hospital.dao.PatientDAO;
import com.hospital.util.AuditLogger;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/PatientProfileServlet")
public class PatientProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        Integer userId = (Integer) session.getAttribute("userId");

        if ("update".equals(action)) {
            String patientIdStr = request.getParameter("patientId");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String dob = request.getParameter("dob");
            String gender = request.getParameter("gender");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String bloodGroup = request.getParameter("bloodGroup");
            String allergies = request.getParameter("allergies");
            String medicalHistory = request.getParameter("medicalHistory");

            int patientId = Integer.parseInt(patientIdStr);

            boolean updated = PatientDAO.updatePatient(patientId, firstName, lastName, dob, gender, phone, 
                                                      address, bloodGroup, allergies, medicalHistory);
            
            if (updated) {
                AuditLogger.logAction(userId, "UPDATE", "patient", patientId, "", firstName + " " + lastName);
                response.sendRedirect("patient_profile.jsp?success=updated");
            } else {
                response.sendRedirect("patient_profile.jsp?error=failed");
            }
        }
    }
}
