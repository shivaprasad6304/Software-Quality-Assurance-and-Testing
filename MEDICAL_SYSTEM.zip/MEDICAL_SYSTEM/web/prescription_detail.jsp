<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.*,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    String prescriptionIdStr = request.getParameter("prescriptionId");
    if (prescriptionIdStr == null) {
        response.sendRedirect("prescriptions.jsp");
        return;
    }

    int prescriptionId = Integer.parseInt(prescriptionIdStr);
    PrescriptionDAO.Prescription prescription = PrescriptionDAO.getPrescriptionById(prescriptionId);
    
    if (prescription == null) {
        response.sendRedirect("prescriptions.jsp");
        return;
    }

    PatientDAO.Patient patient = PatientDAO.getPatientById(prescription.patientId);
    DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(prescription.doctorId);
    List<PrescriptionDAO.PrescriptionDetail> details = PrescriptionDAO.getPrescriptionDetails(prescriptionId);
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription Details - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="prescriptions.jsp">Back to Prescriptions</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Prescription #<%= prescriptionId %></h2>

            <div style="background: #f7fafc; padding: 1.5rem; border-radius: 4px; margin-bottom: 1.5rem;">
                <div class="form-row-3">
                    <div>
                        <strong>Patient:</strong> <br>
                        <%= patient != null ? patient.firstName + " " + patient.lastName : "N/A" %>
                    </div>
                    <div>
                        <strong>Doctor:</strong> <br>
                        <%= doctor != null ? doctor.firstName + " " + doctor.lastName : "N/A" %>
                    </div>
                    <div>
                        <strong>Date:</strong> <br>
                        <%= prescription.createdDate %>
                    </div>
                </div>
                <div style="margin-top: 1rem;">
                    <strong>Status:</strong> 
                    <% if ("active".equals(prescription.status)) { %>
                        <span style="color: green; font-weight: bold;">● Active</span>
                    <% } else { %>
                        <span style="color: gray;"><%= prescription.status %></span>
                    <% } %>
                </div>
                <div style="margin-top: 1rem;">
                    <strong>Notes:</strong> <br>
                    <%= prescription.notes != null ? prescription.notes : "No notes" %>
                </div>
            </div>

            <h3 style="margin-top: 2rem; margin-bottom: 1rem;">Prescribed Medications</h3>

            <% if (details.isEmpty()) { %>
                <p style="text-align: center; color: #999;">No medications prescribed</p>
            <% } else { %>
                <table>
                    <thead>
                        <tr>
                            <th>Medication</th>
                            <th>Dosage</th>
                            <th>Frequency</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Validation</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (PrescriptionDAO.PrescriptionDetail detail : details) {
                            MedicationDAO.Medication med = MedicationDAO.getMedicationById(detail.medicationId);
                        %>
                            <tr>
                                <td><strong><%= med != null ? med.name : "Unknown" %></strong></td>
                                <td><%= detail.dosage %> <%= detail.dosageUnit %></td>
                                <td><%= detail.frequency %></td>
                                <td><%= detail.durationDays %> days</td>
                                <td>
                                    <% if (detail.isValidated) { %>
                                        <span style="color: green; font-weight: bold;">✓ Validated</span>
                                    <% } else { %>
                                        <span style="color: orange;">⚠ Pending</span>
                                    <% } %>
                                </td>
                                <td>
                                    <% if ("validated".equals(detail.validationStatus)) { %>
                                        <span style="color: green; font-weight: bold;">PASSED</span>
                                    <% } else if ("rejected".equals(detail.validationStatus)) { %>
                                        <span style="color: red; font-weight: bold;">REJECTED</span>
                                    <% } else { %>
                                        <span style="color: orange;">PENDING</span>
                                    <% } %>
                                </td>
                                <td>
                                    <% if (detail.validationMessage != null && !detail.validationMessage.isEmpty()) { %>
                                        <div class="<%= "validated".equals(detail.validationStatus) ? "validation-message validation-success" : "validation-message validation-error" %>" 
                                             style="padding: 0.5rem; font-size: 0.85rem; margin: 0;">
                                            <%= detail.validationMessage %>
                                        </div>
                                    <% } else { %>
                                        <span>-</span>
                                    <% } %>
                                </td>
                            </tr>
                            <% if (detail.specialInstructions != null && !detail.specialInstructions.isEmpty()) { %>
                                <tr style="background-color: #f9fafb;">
                                    <td colspan="7" style="padding: 0.75rem;">
                                        <strong>Special Instructions:</strong> <%= detail.specialInstructions %>
                                    </td>
                                </tr>
                            <% } %>
                        <% } %>
                    </tbody>
                </table>
            <% } %>

            <div style="margin-top: 2rem; display: flex; gap: 1rem;">
                <a href="prescriptions.jsp" class="btn btn-secondary">Back to List</a>
                <% if ("doctor".equals(userRole) || "admin".equals(userRole)) { %>
                    <button class="btn btn-danger" onclick="deletePrescription(<%= prescriptionId %>)">Delete Prescription</button>
                <% } %>
            </div>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h3>Patient Information</h3>
            <div style="background: #f7fafc; padding: 1.5rem; border-radius: 4px;">
                <div class="form-row-3">
                    <div>
                        <strong>Blood Group:</strong> <br>
                        <%= patient != null ? patient.bloodGroup : "N/A" %>
                    </div>
                    <div>
                        <strong>Date of Birth:</strong> <br>
                        <%= patient != null ? patient.dateOfBirth : "N/A" %>
                    </div>
                    <div>
                        <strong>Phone:</strong> <br>
                        <%= patient != null ? patient.phone : "N/A" %>
                    </div>
                </div>
                <% if (patient != null && patient.allergies != null && !patient.allergies.isEmpty()) { %>
                    <div style="margin-top: 1rem; padding: 1rem; background-color: #fed7d7; border-left: 4px solid #fc8181; border-radius: 4px;">
                        <strong style="color: #742a2a;">⚠ Allergies:</strong> <br>
                        <span style="color: #742a2a;"><%= patient.allergies %></span>
                    </div>
                <% } %>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function deletePrescription(prescriptionId) {
            if (confirm('Are you sure you want to delete this prescription?')) {
                window.location.href = 'PrescriptionServlet?action=delete&prescriptionId=' + prescriptionId;
            }
        }
    </script>
</body>
</html>
