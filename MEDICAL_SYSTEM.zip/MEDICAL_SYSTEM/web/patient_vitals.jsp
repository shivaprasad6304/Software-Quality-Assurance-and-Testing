<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.PatientDAO.*,com.hospital.dao.PatientDAO,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null) {
        response.sendRedirect("dashboard.jsp");
        return;
    }
    
    // Check if user is nurse
    if (!"nurse".equals(userRole)) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    String patientIdStr = request.getParameter("patientId");
    PatientDAO.Patient patient = null;
    if (patientIdStr != null && !patientIdStr.isEmpty()) {
        int patientId = Integer.parseInt(patientIdStr);
        patient = PatientDAO.getPatientById(patientId);
    }
    
    List<PatientDAO.Patient> patients = PatientDAO.getAllPatients();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Vitals - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .vitals-form {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin: 1.5rem 0;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group label {
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .form-group input {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="nurse_patients.jsp">Patients</a>
            <a href="care_notes.jsp">Care Notes</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Record Patient Vitals</h2>

            <% if (patient != null) { %>
                <div style="background-color: #f0f4f8; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem;">
                    <h3><%= patient.firstName %> <%= patient.lastName %></h3>
                    <p>Patient ID: <%= patient.patientId %> | DOB: <%= patient.dateOfBirth %> | Gender: <%= patient.gender %></p>
                </div>

                <form method="POST" action="#">
                    <div class="vitals-form">
                        <div class="form-group">
                            <label for="temperature">Temperature (°C)</label>
                            <input type="number" id="temperature" name="temperature" step="0.1" min="30" max="45" placeholder="e.g., 37.5">
                        </div>
                        <div class="form-group">
                            <label for="pulse">Pulse Rate (bpm)</label>
                            <input type="number" id="pulse" name="pulse" min="30" max="200" placeholder="e.g., 72">
                        </div>
                        <div class="form-group">
                            <label for="systolic">Blood Pressure - Systolic (mmHg)</label>
                            <input type="number" id="systolic" name="systolic" min="60" max="250" placeholder="e.g., 120">
                        </div>
                        <div class="form-group">
                            <label for="diastolic">Blood Pressure - Diastolic (mmHg)</label>
                            <input type="number" id="diastolic" name="diastolic" min="40" max="180" placeholder="e.g., 80">
                        </div>
                        <div class="form-group">
                            <label for="spO2">SpO₂ (%)</label>
                            <input type="number" id="spO2" name="spO2" min="50" max="100" placeholder="e.g., 98">
                        </div>
                        <div class="form-group">
                            <label for="respiratoryRate">Respiratory Rate (breaths/min)</label>
                            <input type="number" id="respiratoryRate" name="respiratoryRate" min="8" max="40" placeholder="e.g., 16">
                        </div>
                        <div class="form-group">
                            <label for="weight">Weight (kg)</label>
                            <input type="number" id="weight" name="weight" step="0.1" min="1" placeholder="e.g., 70">
                        </div>
                        <div class="form-group">
                            <label for="height">Height (cm)</label>
                            <input type="number" id="height" name="height" min="1" placeholder="e.g., 170">
                        </div>
                    </div>

                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label for="notes">Observations/Notes</label>
                        <textarea id="notes" name="notes" rows="4" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;"></textarea>
                    </div>

                    <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                        <button type="submit" class="btn btn-success">Save Vitals</button>
                        <button type="button" class="btn btn-secondary" onclick="goBack()">Cancel</button>
                    </div>
                </form>
            <% } else { %>
                <div style="margin: 1.5rem 0;">
                    <p style="margin-bottom: 1rem;">Select a patient to record vitals:</p>
                    <select id="patientSelect" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; width: 100%;">
                        <option value="">-- Select Patient --</option>
                        <% for (PatientDAO.Patient p : patients) { %>
                            <option value="<%= p.patientId %>"><%= p.firstName %> <%= p.lastName %> (ID: <%= p.patientId %>)</option>
                        <% } %>
                    </select>
                    <button class="btn btn-primary" style="margin-top: 1rem;" onclick="selectPatient()">Select</button>
                </div>
            <% } %>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h3>Vital Signs Reference</h3>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem;">
                <div style="padding: 1rem; background-color: #f0f4f8; border-radius: 4px;">
                    <h4>Temperature</h4>
                    <p>Normal: 36.1°C - 37.2°C<br>Fever: > 38°C</p>
                </div>
                <div style="padding: 1rem; background-color: #f0f4f8; border-radius: 4px;">
                    <h4>Pulse Rate</h4>
                    <p>Normal: 60 - 100 bpm<br>Adult resting</p>
                </div>
                <div style="padding: 1rem; background-color: #f0f4f8; border-radius: 4px;">
                    <h4>Blood Pressure</h4>
                    <p>Normal: < 120/80 mmHg<br>High: ≥ 130/80 mmHg</p>
                </div>
                <div style="padding: 1rem; background-color: #f0f4f8; border-radius: 4px;">
                    <h4>SpO₂</h4>
                    <p>Normal: 95% - 100%<br>Low: < 95%</p>
                </div>
                <div style="padding: 1rem; background-color: #f0f4f8; border-radius: 4px;">
                    <h4>Respiratory Rate</h4>
                    <p>Normal: 12 - 20 breaths/min<br>Adult at rest</p>
                </div>
                <div style="padding: 1rem; background-color: #f0f4f8; border-radius: 4px;">
                    <h4>BMI</h4>
                    <p>Normal: 18.5 - 24.9<br>Calculated from height/weight</p>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function selectPatient() {
            const patientId = document.getElementById('patientSelect').value;
            if (patientId) {
                window.location.href = 'patient_vitals.jsp?patientId=' + patientId;
            } else {
                alert('Please select a patient');
            }
        }

        function goBack() {
            window.location.href = 'nurse_patients.jsp';
        }
    </script>
</body>
</html>
