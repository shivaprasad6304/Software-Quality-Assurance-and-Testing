<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null || !("patient".equals(userRole))) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    PatientDAO.Patient patient = PatientDAO.getPatientByUserId(userId);
    if (patient == null) {
        patient = PatientDAO.getPatientById(userId);
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="patient_prescriptions.jsp">My Prescriptions</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>My Patient Profile</h2>

            <% String success = request.getParameter("success");
               if (success != null) { %>
                <div class="alert alert-success">
                    Profile updated successfully!
                </div>
            <% } %>

            <% if (patient != null) { %>
                <form method="POST" action="PatientProfileServlet">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="patientId" value="<%= patient.patientId %>">

                    <h3 style="margin-top: 0; margin-bottom: 1.5rem;">Personal Information</h3>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="firstName">First Name:</label>
                            <input type="text" id="firstName" name="firstName" value="<%= patient.firstName %>" required>
                        </div>
                        <div class="form-group">
                            <label for="lastName">Last Name:</label>
                            <input type="text" id="lastName" name="lastName" value="<%= patient.lastName %>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="dob">Date of Birth:</label>
                            <input type="date" id="dob" name="dob" value="<%= patient.dateOfBirth != null ? patient.dateOfBirth : "" %>">
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender:</label>
                            <select id="gender" name="gender">
                                <option value="">Select</option>
                                <option value="Male" <%= "Male".equals(patient.gender) ? "selected" : "" %>>Male</option>
                                <option value="Female" <%= "Female".equals(patient.gender) ? "selected" : "" %>>Female</option>
                                <option value="Other" <%= "Other".equals(patient.gender) ? "selected" : "" %>>Other</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="phone">Phone:</label>
                            <input type="text" id="phone" name="phone" value="<%= patient.phone != null ? patient.phone : "" %>">
                        </div>
                        <div class="form-group">
                            <label for="bloodGroup">Blood Group:</label>
                            <select id="bloodGroup" name="bloodGroup">
                                <option value="">Select</option>
                                <option value="O+" <%= "O+".equals(patient.bloodGroup) ? "selected" : "" %>>O+</option>
                                <option value="O-" <%= "O-".equals(patient.bloodGroup) ? "selected" : "" %>>O-</option>
                                <option value="A+" <%= "A+".equals(patient.bloodGroup) ? "selected" : "" %>>A+</option>
                                <option value="A-" <%= "A-".equals(patient.bloodGroup) ? "selected" : "" %>>A-</option>
                                <option value="B+" <%= "B+".equals(patient.bloodGroup) ? "selected" : "" %>>B+</option>
                                <option value="B-" <%= "B-".equals(patient.bloodGroup) ? "selected" : "" %>>B-</option>
                                <option value="AB+" <%= "AB+".equals(patient.bloodGroup) ? "selected" : "" %>>AB+</option>
                                <option value="AB-" <%= "AB-".equals(patient.bloodGroup) ? "selected" : "" %>>AB-</option>
                            </select>
                        </div>
                    </div>

                    <h3 style="margin-top: 2rem; margin-bottom: 1.5rem;">Medical Information</h3>

                    <div class="form-group">
                        <label for="allergies">Known Allergies:</label>
                        <textarea id="allergies" name="allergies" rows="3" placeholder="List any medications or substances you are allergic to"><%= patient.allergies != null ? patient.allergies : "" %></textarea>
                    </div>

                    <div class="form-group">
                        <label for="medicalHistory">Medical History:</label>
                        <textarea id="medicalHistory" name="medicalHistory" rows="3" placeholder="Any relevant medical conditions or past treatments"><%= patient.medicalHistory != null ? patient.medicalHistory : "" %></textarea>
                    </div>

                    <div class="form-group">
                        <label for="address">Address:</label>
                        <textarea id="address" name="address" rows="2"><%= patient.address != null ? patient.address : "" %></textarea>
                    </div>

                    <div style="background: #bee3f8; padding: 1rem; border-radius: 4px; margin-top: 1.5rem; border-left: 4px solid #4299e1;">
                        <strong>ℹ Note:</strong> Keep your allergies and medical history up to date. This information is critical for safe prescription management.
                    </div>

                    <div style="margin-top: 1.5rem; display: flex; gap: 1rem;">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='dashboard.jsp'">Cancel</button>
                    </div>
                </form>
            <% } else { %>
                <div class="alert alert-error">
                    Error loading patient profile. Please contact support.
                </div>
            <% } %>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>
</body>
</html>
