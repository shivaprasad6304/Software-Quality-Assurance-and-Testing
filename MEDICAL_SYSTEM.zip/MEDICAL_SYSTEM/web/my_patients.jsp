<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.PatientDAO.*,com.hospital.dao.PatientDAO,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null) {
        response.sendRedirect("dashboard.jsp");
        return;
    }
    
    // Check if user is doctor
    if (!"doctor".equals(userRole)) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    // Get doctor's patients (simplified - get all patients for now)
    List<PatientDAO.Patient> patients = PatientDAO.getAllPatients();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="my_prescriptions.jsp">My Prescriptions</a>
            <a href="create_prescription.jsp">Create Prescription</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>My Patients</h2>

            <table style="margin-top: 1.5rem;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Blood Group</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (patients.isEmpty()) { %>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 2rem;">No patients found</td>
                        </tr>
                    <% } else {
                        for (PatientDAO.Patient patient : patients) {
                    %>
                        <tr>
                            <td><%= patient.patientId %></td>
                            <td><%= patient.firstName %> <%= patient.lastName %></td>
                            <td><%= patient.dateOfBirth %></td>
                            <td><%= patient.gender %></td>
                            <td><%= patient.phone %></td>
                            <td><%= patient.address %></td>
                            <td><%= patient.bloodGroup %></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary" onclick="viewPatient(<%= patient.patientId %>)">View</button>
                                    <button class="btn btn-primary" onclick="createPrescription(<%= patient.patientId %>)">Create Rx</button>
                                </div>
                            </td>
                        </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h3>Patient Statistics</h3>
            <div class="dashboard-grid">
                <div class="stat-card">
                    <h3>Total Patients</h3>
                    <div class="number"><%= patients.size() %></div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function viewPatient(patientId) {
            window.location.href = 'patient_profile.jsp?patientId=' + patientId;
        }

        function createPrescription(patientId) {
            window.location.href = 'create_prescription.jsp?patientId=' + patientId;
        }
    </script>
</body>
</html>
