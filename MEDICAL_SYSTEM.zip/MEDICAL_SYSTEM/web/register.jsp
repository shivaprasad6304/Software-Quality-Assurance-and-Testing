<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Management System - Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="card" style="max-width: 500px; margin: 2rem auto;">
            <h1 style="text-align: center; color: #667eea; margin-bottom: 2rem;">Create an Account</h1>
            
            <% String error = request.getParameter("error");
               if (error != null && !error.isEmpty()) { %>
                <div class="alert alert-error">
                    <strong>Registration Error:</strong>
                    <% if (error.equals("username_exists")) { %>
                        Username already exists. Please choose a different username.
                    <% } else if (error.equals("invalid")) { %>
                        Invalid input. Please check your information.
                    <% } else { %>
                        Registration failed. Please try again.
                    <% } %>
                </div>
            <% } %>

            <form method="POST" action="RegisterServlet">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" placeholder="Choose a username" required>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter a strong password" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                </div>

                <div class="form-group">
                    <label for="role">Register As:</label>
                    <select id="role" name="role" required>
                        <option value="">Select a role</option>
                        <option value="patient">Patient</option>
                        <option value="doctor">Doctor</option>
                        <option value="pharmacist">Pharmacist</option>
                        <option value="nurse">Nurse</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">Register</button>
            </form>

            <p style="text-align: center; margin-top: 1.5rem;">
                Already have an account? <a href="login.jsp" style="color: #667eea; text-decoration: none;">Login here</a>
            </p>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        document.querySelector('form').addEventListener('submit', function(e) {
            var password = document.getElementById('password').value;
            var confirm = document.getElementById('confirm_password').value;
            
            if (password !== confirm) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }

            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long!');
                return false;
            }
        });
    </script>
</body>
</html>
