<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Management System - Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="card" style="max-width: 400px; margin: 5rem auto;">
            <h1 style="text-align: center; color: #667eea; margin-bottom: 2rem;">Hospital Management System</h1>
            
            <% String error = request.getParameter("error");
               if (error != null && !error.isEmpty()) { %>
                <div class="alert alert-error">
                    <strong>Login Failed:</strong>
                    <% if (error.equals("invalid")) { %>
                        Invalid username or password
                    <% } else if (error.equals("required")) { %>
                        Username and password are required
                    <% } else { %>
                        An error occurred during login
                    <% } %>
                </div>
            <% } %>

            <% String success = request.getParameter("success");
               if (success != null && !success.isEmpty()) { %>
                <div class="alert alert-success">
                    Registration successful! Please log in with your credentials.
                </div>
            <% } %>

            <form method="POST" action="LoginServlet">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">Login</button>
            </form>

            <p style="text-align: center; margin-top: 1.5rem;">
                Don't have an account? <a href="register.jsp" style="color: #667eea; text-decoration: none;">Register here</a>
            </p>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>
</body>
</html>
