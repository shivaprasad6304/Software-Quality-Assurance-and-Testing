<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.PrescriptionDAO.*,com.hospital.dao.*,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    List<PrescriptionDAO.Prescription> prescriptions = PrescriptionDAO.getAllPrescriptions();
    List<PatientDAO.Patient> patients = PatientDAO.getAllPatients();
    List<DoctorDAO.Doctor> doctors = DoctorDAO.getAllDoctors();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription Management - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <% if ("doctor".equals(userRole)) { %>
                <a href="create_prescription.jsp">Create Prescription</a>
            <% } %>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>All Prescriptions</h2>

            <table style="margin-top: 1.5rem;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Medications</th>
                        <th>Alerts</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (prescriptions.isEmpty()) { %>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 2rem;">No prescriptions found</td>
                        </tr>
                    <% } else {
                        for (PrescriptionDAO.Prescription prescription : prescriptions) {
                            PatientDAO.Patient patient = PatientDAO.getPatientById(prescription.patientId);
                            DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(prescription.doctorId);
                            List<PrescriptionDAO.PrescriptionDetail> details = PrescriptionDAO.getPrescriptionDetails(prescription.prescriptionId);
                    %>
                        <tr>
                            <td><%= prescription.prescriptionId %></td>
                            <td><%= patient != null ? patient.firstName + " " + patient.lastName : "N/A" %></td>
                            <td><%= doctor != null ? doctor.firstName + " " + doctor.lastName : "N/A" %></td>
                            <td><%= prescription.createdDate %></td>
                            <td>
                                <% if ("active".equals(prescription.status)) { %>
                                    <span style="color: green; font-weight: bold;">Active</span>
                                <% } else { %>
                                    <span style="color: gray;"><%= prescription.status %></span>
                                <% } %>
                            </td>
                            <td><%= details.size() %> medication(s)</td>
                            <td>
                                <% 
                                    int alertCount = 0;
                                    for (PrescriptionDAO.PrescriptionDetail detail : details) {
                                        if (!"validated".equals(detail.validationStatus)) {
                                            alertCount++;
                                        }
                                    }
                                %>
                                <% if (alertCount > 0) { %>
                                    <span style="color: red; font-weight: bold;">⚠ <%= alertCount %></span>
                                <% } else { %>
                                    <span style="color: green;">✓</span>
                                <% } %>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary" onclick="viewPrescription(<%= prescription.prescriptionId %>)">View</button>
                                    <% if ("doctor".equals(userRole) || "admin".equals(userRole)) { %>
                                        <button class="btn btn-danger" onclick="deletePrescription(<%= prescription.prescriptionId %>)">Delete</button>
                                    <% } %>
                                </div>
                            </td>
                        </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h3>Prescription Statistics</h3>
            <div class="dashboard-grid">
                <div class="stat-card">
                    <h3>Total Prescriptions</h3>
                    <div class="number"><%= prescriptions.size() %></div>
                </div>
                <div class="stat-card">
                    <h3>Active</h3>
                    <div class="number"><%= prescriptions.stream().filter(p -> "active".equals(p.status)).count() %></div>
                </div>
                <div class="stat-card">
                    <h3>Completed</h3>
                    <div class="number"><%= prescriptions.stream().filter(p -> "completed".equals(p.status)).count() %></div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function viewPrescription(prescriptionId) {
            window.location.href = 'prescription_detail.jsp?prescriptionId=' + prescriptionId;
        }

        function deletePrescription(prescriptionId) {
            if (confirm('Are you sure you want to delete this prescription?')) {
                window.location.href = 'PrescriptionServlet?action=delete&prescriptionId=' + prescriptionId;
            }
        }
    </script>
</body>
</html>
