<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.*,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null || !("patient".equals(userRole))) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    PatientDAO.Patient currentPatient = PatientDAO.getPatientByUserId(userId);
    List<PrescriptionDAO.Prescription> prescriptions = new java.util.ArrayList<>();
    
    if (currentPatient != null) {
        prescriptions = PrescriptionDAO.getPrescriptionsByPatientId(currentPatient.patientId);
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Prescriptions - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="patient_profile.jsp">My Profile</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>My Prescriptions</h2>

            <div style="background: #bee3f8; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem; border-left: 4px solid #4299e1;">
                <strong>ℹ Information:</strong> All your active prescriptions are listed below. Click on a prescription to view detailed information including medication instructions.
            </div>

            <table style="margin-top: 1.5rem;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Medications</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (prescriptions.isEmpty()) { %>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 2rem;">
                                <p style="color: #666; margin: 0;">No prescriptions available</p>
                            </td>
                        </tr>
                    <% } else {
                        for (PrescriptionDAO.Prescription prescription : prescriptions) {
                            DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(prescription.doctorId);
                            List<PrescriptionDAO.PrescriptionDetail> details = PrescriptionDAO.getPrescriptionDetails(prescription.prescriptionId);
                    %>
                        <tr>
                            <td><%= prescription.prescriptionId %></td>
                            <td><%= doctor != null ? doctor.firstName + " " + doctor.lastName : "N/A" %></td>
                            <td><%= prescription.createdDate %></td>
                            <td>
                                <% if ("active".equals(prescription.status)) { %>
                                    <span style="color: green; font-weight: bold;">● Active</span>
                                <% } else { %>
                                    <span style="color: gray;"><%= prescription.status %></span>
                                <% } %>
                            </td>
                            <td><%= details.size() %> medication(s)</td>
                            <td>
                                <button class="btn btn-secondary" onclick="viewPrescription(<%= prescription.prescriptionId %>)">View Details</button>
                            </td>
                        </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>

        <% if (currentPatient != null && currentPatient.allergies != null && !currentPatient.allergies.isEmpty()) { %>
            <div class="card" style="margin-top: 2rem;">
                <h3>⚠ Your Allergies</h3>
                <div style="background: #fed7d7; padding: 1.5rem; border-left: 4px solid #fc8181; border-radius: 4px; color: #742a2a;">
                    <p style="margin: 0;">
                        <strong>Important:</strong> Your registered allergies are:
                    </p>
                    <p style="margin: 0.5rem 0 0 0;">
                        <%= currentPatient.allergies %>
                    </p>
                    <p style="margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                        Please inform your healthcare provider if you develop any new allergies.
                    </p>
                </div>
            </div>
        <% } %>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function viewPrescription(prescriptionId) {
            window.location.href = 'prescription_detail.jsp?prescriptionId=' + prescriptionId;
        }
    </script>
</body>
</html>
