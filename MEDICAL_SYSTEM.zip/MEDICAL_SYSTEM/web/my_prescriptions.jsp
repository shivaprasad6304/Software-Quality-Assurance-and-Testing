<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.*,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null || !("doctor".equals(userRole))) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    DoctorDAO.Doctor doctor = DoctorDAO.getDoctorByUserId(userId);
    List<PrescriptionDAO.Prescription> prescriptions = new java.util.ArrayList<>();
    
    if (doctor != null) {
        List<PrescriptionDAO.Prescription> allPrescriptions = PrescriptionDAO.getAllPrescriptions();
        for (PrescriptionDAO.Prescription p : allPrescriptions) {
            if (p.doctorId == doctor.doctorId) {
                prescriptions.add(p);
            }
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Prescriptions - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="create_prescription.jsp">Create Prescription</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>My Prescriptions</h2>

            <% String success = request.getParameter("success");
               if (success != null && "created".equals(success)) { %>
                <div class="alert alert-success">
                    Prescription created successfully!
                </div>
            <% } %>

            <table style="margin-top: 1.5rem;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Medications</th>
                        <th>Alerts</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (prescriptions.isEmpty()) { %>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 2rem;">No prescriptions created yet</td>
                        </tr>
                    <% } else {
                        for (PrescriptionDAO.Prescription prescription : prescriptions) {
                            PatientDAO.Patient patient = PatientDAO.getPatientById(prescription.patientId);
                            List<PrescriptionDAO.PrescriptionDetail> details = PrescriptionDAO.getPrescriptionDetails(prescription.prescriptionId);
                    %>
                        <tr>
                            <td><%= prescription.prescriptionId %></td>
                            <td><%= patient != null ? patient.firstName + " " + patient.lastName : "N/A" %></td>
                            <td><%= prescription.createdDate %></td>
                            <td>
                                <% if ("active".equals(prescription.status)) { %>
                                    <span style="color: green; font-weight: bold;">Active</span>
                                <% } else { %>
                                    <span style="color: gray;"><%= prescription.status %></span>
                                <% } %>
                            </td>
                            <td><%= details.size() %></td>
                            <td>
                                <% 
                                    int alertCount = 0;
                                    for (PrescriptionDAO.PrescriptionDetail detail : details) {
                                        if (!"validated".equals(detail.validationStatus)) {
                                            alertCount++;
                                        }
                                    }
                                %>
                                <% if (alertCount > 0) { %>
                                    <span style="color: red; font-weight: bold;">⚠ <%= alertCount %></span>
                                <% } else { %>
                                    <span style="color: green;">✓</span>
                                <% } %>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary" onclick="viewPrescription(<%= prescription.prescriptionId %>)">View</button>
                                    <button class="btn btn-danger" onclick="deletePrescription(<%= prescription.prescriptionId %>)">Delete</button>
                                </div>
                            </td>
                        </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function viewPrescription(prescriptionId) {
            window.location.href = 'prescription_detail.jsp?prescriptionId=' + prescriptionId;
        }

        function deletePrescription(prescriptionId) {
            if (confirm('Are you sure you want to delete this prescription?')) {
                window.location.href = 'PrescriptionServlet?action=delete&prescriptionId=' + prescriptionId;
            }
        }
    </script>
</body>
</html>
