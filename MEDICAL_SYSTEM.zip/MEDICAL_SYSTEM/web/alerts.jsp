<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.hospital.util.DBConnection" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    // Get alerts from database
    java.util.List<java.util.Map<String, Object>> alerts = new java.util.ArrayList<>();
    
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        conn = DBConnection.getConnection();
        String query = "SELECT a.alert_id, a.alert_type, a.severity, a.message, a.created_at, a.is_resolved, " +
                      "pd.dosage, m.name as medication_name, p.patient_id " +
                      "FROM alerts a " +
                      "LEFT JOIN prescription_details pd ON a.prescription_detail_id = pd.detail_id " +
                      "LEFT JOIN medications m ON pd.medication_id = m.medication_id " +
                      "LEFT JOIN prescriptions pr ON pd.prescription_id = pr.prescription_id " +
                      "LEFT JOIN patients p ON pr.patient_id = p.patient_id " +
                      "ORDER BY a.created_at DESC LIMIT 100";
        
        pstmt = conn.prepareStatement(query);
        rs = pstmt.executeQuery();

        while (rs.next()) {
            java.util.Map<String, Object> alert = new java.util.HashMap<>();
            alert.put("alertId", rs.getInt("alert_id"));
            alert.put("alertType", rs.getString("alert_type"));
            alert.put("severity", rs.getString("severity"));
            alert.put("message", rs.getString("message"));
            alert.put("createdAt", rs.getString("created_at"));
            alert.put("isResolved", rs.getBoolean("is_resolved"));
            alert.put("medicationName", rs.getString("medication_name"));
            alert.put("dosage", rs.getDouble("dosage"));
            alerts.add(alert);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        DBConnection.closeConnection(conn);
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alerts & Warnings - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>System Alerts & Warnings</h2>

            <div style="background: #feebc8; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem; border-left: 4px solid #ed8936;">
                <strong>⚠ Alert Summary:</strong> 
                <% 
                    int totalAlerts = alerts.size();
                    int severeCount = 0;
                    int moderateCount = 0;
                    int warningCount = 0;
                    
                    for (java.util.Map<String, Object> alert : alerts) {
                        String severity = (String) alert.get("severity");
                        if ("severe".equals(severity)) severeCount++;
                        else if ("moderate".equals(severity)) moderateCount++;
                        else if ("warning".equals(severity)) warningCount++;
                    }
                %>
                <%= totalAlerts %> total alerts
                <% if (severeCount > 0) { %>
                    | <span style="color: #c53030;"><strong><%= severeCount %> SEVERE</strong></span>
                <% } %>
                <% if (moderateCount > 0) { %>
                    | <span style="color: #d97706;"><strong><%= moderateCount %> MODERATE</strong></span>
                <% } %>
                <% if (warningCount > 0) { %>
                    | <span style="color: #d97706;"><strong><%= warningCount %> WARNING</strong></span>
                <% } %>
            </div>

            <% if (alerts.isEmpty()) { %>
                <div style="text-align: center; padding: 2rem; background: #c6f6d5; border-radius: 4px; border-left: 4px solid #48bb78;">
                    <h3 style="color: #22543d;">✓ No Alerts</h3>
                    <p style="color: #22543d;">All systems operating normally. No warnings or errors detected.</p>
                </div>
            <% } else { %>
                <div>
                    <% for (java.util.Map<String, Object> alert : alerts) {
                        String severity = (String) alert.get("severity");
                        String alertType = (String) alert.get("alertType");
                        String severityClass = "severe".equals(severity) ? "alert-error" : "warning".equals(severity) ? "alert-warning" : "alert-info";
                        String severityColor = "severe".equals(severity) ? "red" : "orange";
                    %>
                        <div style="background: white; border-left: 4px solid <%= "severe".equals(severity) ? "#f56565" : "orange" %>; padding: 1.5rem; margin-bottom: 1rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                            <div style="display: flex; justify-content: space-between; align-items: start;">
                                <div>
                                    <h4 style="margin: 0 0 0.5rem 0; color: #333;">
                                        <% if ("severe".equals(severity)) { %>
                                            ⛔ SEVERE
                                        <% } else if ("moderate".equals(severity)) { %>
                                            ⚠ MODERATE
                                        <% } else { %>
                                            ⓘ WARNING
                                        <% } %>
                                        - <%= alertType.toUpperCase().replace("_", " ") %>
                                    </h4>
                                    <p style="margin: 0.5rem 0; color: #666;">
                                        <strong>Type:</strong> 
                                        <% if ("dosage_error".equals(alertType)) { %>
                                            Dosage Error
                                        <% } else if ("drug_interaction".equals(alertType)) { %>
                                            Drug Interaction
                                        <% } else if ("allergies".equals(alertType)) { %>
                                            Patient Allergy
                                        <% } else { %>
                                            <%= alertType %>
                                        <% } %>
                                    </p>
                                    <% if (alert.get("medicationName") != null) { %>
                                        <p style="margin: 0.5rem 0; color: #666;">
                                            <strong>Medication:</strong> <%= alert.get("medicationName") %>
                                        </p>
                                    <% } %>
                                    <p style="margin: 0.5rem 0; color: #333;">
                                        <strong>Message:</strong> <%= alert.get("message") %>
                                    </p>
                                    <p style="margin: 0.5rem 0; color: #999; font-size: 0.9rem;">
                                        <strong>Date:</strong> <%= alert.get("createdAt") %>
                                    </p>
                                </div>
                                <div style="text-align: right;">
                                    <% if ((Boolean) alert.get("isResolved")) { %>
                                        <span style="background: #c6f6d5; color: #22543d; padding: 0.5rem 1rem; border-radius: 4px; font-weight: bold;">✓ Resolved</span>
                                    <% } else { %>
                                        <span style="background: #fed7d7; color: #742a2a; padding: 0.5rem 1rem; border-radius: 4px; font-weight: bold;">⚠ Unresolved</span>
                                    <% } %>
                                </div>
                            </div>
                        </div>
                    <% } %>
                </div>
            <% } %>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h3>Alert Types & Meanings</h3>
            <div style="background: #f7fafc; padding: 1.5rem; border-radius: 4px;">
                <div style="margin-bottom: 1.5rem;">
                    <h4 style="color: #c53030; margin-bottom: 0.5rem;">⛔ Dosage Error (SEVERE)</h4>
                    <p style="margin: 0; color: #666;">
                        The prescribed dosage exceeds the safe maximum limit for the medication. Immediate review required.
                    </p>
                </div>
                <div style="margin-bottom: 1.5rem;">
                    <h4 style="color: #d97706; margin-bottom: 0.5rem;">⚠ Drug Interaction (WARNING)</h4>
                    <p style="margin: 0; color: #666;">
                        Two or more medications in the prescription may interact negatively. Clinical review recommended.
                    </p>
                </div>
                <div style="margin-bottom: 1.5rem;">
                    <h4 style="color: #d97706; margin-bottom: 0.5rem;">ⓘ Patient Allergy (WARNING)</h4>
                    <p style="margin: 0; color: #666;">
                        The prescribed medication matches a known patient allergy. Prescription should be revised.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>
</body>
</html>
