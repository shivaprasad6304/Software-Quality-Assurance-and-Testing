<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.DoctorDAO.*,com.hospital.dao.DoctorDAO,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null || !("admin".equals(userRole))) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    List<DoctorDAO.Doctor> doctors = DoctorDAO.getAllDoctors();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Management - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Doctor Management</h2>
            <button class="btn btn-primary" onclick="openModal('addDoctorModal')">Add New Doctor</button>

            <table style="margin-top: 1.5rem;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>License Number</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (doctors.isEmpty()) { %>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 2rem;">No doctors found</td>
                        </tr>
                    <% } else {
                        for (DoctorDAO.Doctor doctor : doctors) {
                    %>
                        <tr>
                            <td><%= doctor.doctorId %></td>
                            <td><%= doctor.firstName %> <%= doctor.lastName %></td>
                            <td><%= doctor.specialization %></td>
                            <td><%= doctor.licenseNumber %></td>
                            <td><%= doctor.phone %></td>
                            <td><%= doctor.email %></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary" onclick="editDoctor(<%= doctor.doctorId %>)">Edit</button>
                                    <button class="btn btn-danger" onclick="deleteDoctor(<%= doctor.doctorId %>)">Delete</button>
                                </div>
                            </td>
                        </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add/Edit Doctor Modal -->
    <div id="addDoctorModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Doctor</h2>
                <span class="close" onclick="closeModal('addDoctorModal')">&times;</span>
            </div>
            <form method="POST" action="DoctorServlet">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="doctorId" id="doctorId">

                <div class="form-row">
                    <div class="form-group">
                        <label for="firstName">First Name:</label>
                        <input type="text" id="firstName" name="firstName" required>
                    </div>
                    <div class="form-group">
                        <label for="lastName">Last Name:</label>
                        <input type="text" id="lastName" name="lastName" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="specialization">Specialization:</label>
                    <select id="specialization" name="specialization" required>
                        <option value="">Select Specialization</option>
                        <option value="Cardiology">Cardiology</option>
                        <option value="Neurology">Neurology</option>
                        <option value="Orthopedics">Orthopedics</option>
                        <option value="Pediatrics">Pediatrics</option>
                        <option value="Dermatology">Dermatology</option>
                        <option value="General Medicine">General Medicine</option>
                        <option value="Surgery">Surgery</option>
                        <option value="Psychiatry">Psychiatry</option>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="licenseNumber">License Number:</label>
                        <input type="text" id="licenseNumber" name="licenseNumber" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone:</label>
                        <input type="text" id="phone" name="phone">
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email">
                </div>

                <button type="submit" class="btn btn-success" style="width: 100%;">Save Doctor</button>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).classList.add('show');
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }

        function editDoctor(doctorId) {
            openModal('addDoctorModal');
        }

        function deleteDoctor(doctorId) {
            if (confirm('Are you sure you want to delete this doctor?')) {
                window.location.href = 'DoctorServlet?action=delete&doctorId=' + doctorId;
            }
        }

        window.onclick = function(event) {
            let modal = document.getElementById('addDoctorModal');
            if (event.target === modal) {
                modal.classList.remove('show');
            }
        }
    </script>
</body>
</html>
