<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.PatientDAO.*,com.hospital.dao.PatientDAO,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null || !("admin".equals(userRole))) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    List<PatientDAO.Patient> patients = PatientDAO.getAllPatients();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Management - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Patient Management</h2>
            <button class="btn btn-primary" onclick="openModal('addPatientModal')">Add New Patient</button>

            <table style="margin-top: 1.5rem;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Phone</th>
                        <th>Blood Group</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (patients.isEmpty()) { %>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 2rem;">No patients found</td>
                        </tr>
                    <% } else {
                        for (PatientDAO.Patient patient : patients) {
                    %>
                        <tr>
                            <td><%= patient.patientId %></td>
                            <td><%= patient.firstName %> <%= patient.lastName %></td>
                            <td><%= patient.dateOfBirth %></td>
                            <td><%= patient.gender %></td>
                            <td><%= patient.phone %></td>
                            <td><%= patient.bloodGroup %></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary" onclick="editPatient(<%= patient.patientId %>)">Edit</button>
                                    <button class="btn btn-danger" onclick="deletePatient(<%= patient.patientId %>)">Delete</button>
                                </div>
                            </td>
                        </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add/Edit Patient Modal -->
    <div id="addPatientModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Patient</h2>
                <span class="close" onclick="closeModal('addPatientModal')">&times;</span>
            </div>
            <form method="POST" action="PatientServlet">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="patientId" id="patientId">

                <div class="form-row">
                    <div class="form-group">
                        <label for="firstName">First Name:</label>
                        <input type="text" id="firstName" name="firstName" required>
                    </div>
                    <div class="form-group">
                        <label for="lastName">Last Name:</label>
                        <input type="text" id="lastName" name="lastName" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="dob">Date of Birth:</label>
                        <input type="date" id="dob" name="dob">
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender:</label>
                        <select id="gender" name="gender">
                            <option value="">Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="phone">Phone:</label>
                        <input type="text" id="phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="bloodGroup">Blood Group:</label>
                        <select id="bloodGroup" name="bloodGroup">
                            <option value="">Select</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="address">Address:</label>
                    <textarea id="address" name="address" rows="2"></textarea>
                </div>

                <div class="form-group">
                    <label for="allergies">Allergies:</label>
                    <textarea id="allergies" name="allergies" rows="2"></textarea>
                </div>

                <div class="form-group">
                    <label for="medicalHistory">Medical History:</label>
                    <textarea id="medicalHistory" name="medicalHistory" rows="3"></textarea>
                </div>

                <button type="submit" class="btn btn-success" style="width: 100%;">Save Patient</button>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).classList.add('show');
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }

        function editPatient(patientId) {
            // In a real application, fetch patient data and populate form
            openModal('addPatientModal');
        }

        function deletePatient(patientId) {
            if (confirm('Are you sure you want to delete this patient?')) {
                window.location.href = 'PatientServlet?action=delete&patientId=' + patientId;
            }
        }

        window.onclick = function(event) {
            let modal = document.getElementById('addPatientModal');
            if (event.target === modal) {
                modal.classList.remove('show');
            }
        }
    </script>
</body>
</html>
