<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.*,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null || !("doctor".equals(userRole))) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    DoctorDAO.Doctor currentDoctor = DoctorDAO.getDoctorByUserId(userId);
    List<PatientDAO.Patient> patients = PatientDAO.getAllPatients();
    List<MedicationDAO.Medication> medications = MedicationDAO.getAllMedications();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Prescription - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Create New Prescription</h2>

            <% String success = request.getParameter("success");
               if (success != null) { %>
                <div class="alert alert-success">
                    Prescription created successfully!
                </div>
            <% } %>

            <form method="POST" action="PrescriptionServlet" id="prescriptionForm">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="doctorId" value="<%= currentDoctor != null ? currentDoctor.doctorId : "" %>">

                <div class="form-group">
                    <label for="patientId">Select Patient:</label>
                    <select id="patientId" name="patientId" required>
                        <option value="">Select a patient</option>
                        <% for (PatientDAO.Patient patient : patients) { %>
                            <option value="<%= patient.patientId %>">
                                <%= patient.firstName %> <%= patient.lastName %> (ID: <%= patient.patientId %>)
                            </option>
                        <% } %>
                    </select>
                </div>

                <div class="form-group">
                    <label for="notes">Prescription Notes:</label>
                    <textarea id="notes" name="notes" rows="3" placeholder="Additional notes for the prescription"></textarea>
                </div>

                <h3 style="margin-top: 2rem; margin-bottom: 1rem;">Add Medications</h3>

                <div id="medicationsList" style="background: #f7fafc; padding: 1.5rem; border-radius: 4px;">
                    <div class="medication-item">
                        <div class="form-row-3">
                            <div class="form-group">
                                <label>Medication:</label>
                                <select name="medicationId[]" class="medicationSelect" onchange="updateDosageLimits(this)" required>
                                    <option value="">Select medication</option>
                                    <% for (MedicationDAO.Medication med : medications) { %>
                                        <option value="<%= med.medicationId %>" 
                                                data-min="<%= med.minSingleDose %>" 
                                                data-max="<%= med.maxSingleDose %>"
                                                data-daily="<%= med.maxDailyDose %>">
                                            <%= med.name %> (<%= med.strength %> <%= med.unit %>)
                                        </option>
                                    <% } %>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Dosage:</label>
                                <input type="number" name="dosage[]" class="dosageInput" step="0.01" placeholder="Enter dosage" required onchange="validateDosage(this)">
                                <small style="color: #666; margin-top: 0.25rem; display: block;">
                                    Min: <span class="minDose">-</span> | Max: <span class="maxDose">-</span>
                                </small>
                            </div>
                            <div class="form-group">
                                <label>Unit:</label>
                                <select name="dosageUnit[]">
                                    <option value="mg">mg</option>
                                    <option value="g">g</option>
                                    <option value="mcg">mcg</option>
                                    <option value="ml">ml</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-row-3">
                            <div class="form-group">
                                <label>Frequency:</label>
                                <select name="frequency[]">
                                    <option value="">Select frequency</option>
                                    <option value="Once daily">Once daily</option>
                                    <option value="Twice daily">Twice daily</option>
                                    <option value="Three times daily">Three times daily</option>
                                    <option value="Four times daily">Four times daily</option>
                                    <option value="Every 6 hours">Every 6 hours</option>
                                    <option value="Every 8 hours">Every 8 hours</option>
                                    <option value="As needed">As needed</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Duration (Days):</label>
                                <input type="number" name="duration[]" min="1" value="7">
                            </div>
                            <div class="form-group">
                                <label>Special Instructions:</label>
                                <input type="text" name="specialInstructions[]" placeholder="e.g., Take with food">
                            </div>
                        </div>

                        <div class="validation-message" style="display: none;"></div>

                        <button type="button" class="btn btn-danger" onclick="removeMedication(this)" style="margin-top: 1rem;">Remove Medication</button>
                        <hr style="margin: 1.5rem 0;">
                    </div>
                </div>

                <button type="button" class="btn btn-secondary" onclick="addMedication()">+ Add Another Medication</button>

                <div style="margin-top: 2rem;">
                    <button type="submit" class="btn btn-primary" onclick="validatePrescription()">Create Prescription</button>
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='dashboard.jsp'" style="margin-left: 1rem;">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function addMedication() {
            const medicationsList = document.getElementById('medicationsList');
            const newItem = document.querySelector('.medication-item').cloneNode(true);
            newItem.querySelector('.medicationSelect').value = '';
            newItem.querySelector('.dosageInput').value = '';
            newItem.querySelector('.validation-message').style.display = 'none';
            medicationsList.appendChild(newItem);
        }

        function removeMedication(button) {
            button.closest('.medication-item').remove();
        }

        function updateDosageLimits(select) {
            const item = select.closest('.medication-item');
            const minDose = select.options[select.selectedIndex].getAttribute('data-min');
            const maxDose = select.options[select.selectedIndex].getAttribute('data-max');
            
            item.querySelector('.minDose').textContent = minDose || '-';
            item.querySelector('.maxDose').textContent = maxDose || '-';
        }

        function validateDosage(input) {
            const item = input.closest('.medication-item');
            const medicationSelect = item.querySelector('.medicationSelect');
            const maxDose = medicationSelect.options[medicationSelect.selectedIndex].getAttribute('data-max');
            const dosage = parseFloat(input.value);
            const messageDiv = item.querySelector('.validation-message');

            if (dosage > maxDose) {
                messageDiv.style.display = 'block';
                messageDiv.className = 'validation-message validation-error';
                messageDiv.textContent = '⚠ Warning: Dosage exceeds maximum safe limit (' + maxDose + ')';
                input.style.borderColor = '#fc8181';
            } else {
                messageDiv.style.display = 'block';
                messageDiv.className = 'validation-message validation-success';
                messageDiv.textContent = '✓ Dosage is within safe limits';
                input.style.borderColor = '#9ae6b4';
            }
        }

        function validatePrescription() {
            const patientId = document.getElementById('patientId').value;
            const medications = document.querySelectorAll('.medication-item');

            if (!patientId) {
                alert('Please select a patient');
                return false;
            }

            let isValid = true;
            medications.forEach(med => {
                const select = med.querySelector('.medicationSelect');
                const dosage = med.querySelector('.dosageInput');
                
                if (!select.value || !dosage.value) {
                    isValid = false;
                    alert('Please fill in all medication fields');
                }
            });

            return isValid;
        }

        // Initialize dose limits for first medication
        window.addEventListener('load', function() {
            const firstSelect = document.querySelector('.medicationSelect');
            if (firstSelect && firstSelect.value) {
                updateDosageLimits(firstSelect);
            }
        });
    </script>
</body>
</html>
