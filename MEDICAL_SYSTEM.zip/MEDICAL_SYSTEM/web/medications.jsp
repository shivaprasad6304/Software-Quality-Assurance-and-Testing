<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.MedicationDAO.*,com.hospital.dao.MedicationDAO,java.util.*" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    List<MedicationDAO.Medication> medications = MedicationDAO.getAllMedications();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medication Management - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Medication Management</h2>
            <% if ("admin".equals(userRole) || "pharmacist".equals(userRole)) { %>
                <button class="btn btn-primary" onclick="openModal('addMedicationModal')">Add New Medication</button>
            <% } %>

            <table style="margin-top: 1.5rem;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Generic Name</th>
                        <th>Strength</th>
                        <th>Min Dose</th>
                        <th>Max Single</th>
                        <th>Max Daily</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (medications.isEmpty()) { %>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 2rem;">No medications found</td>
                        </tr>
                    <% } else {
                        for (MedicationDAO.Medication med : medications) {
                    %>
                        <tr>
                            <td><%= med.medicationId %></td>
                            <td><strong><%= med.name %></strong></td>
                            <td><%= med.genericName %></td>
                            <td><%= med.strength %> <%= med.unit %></td>
                            <td><%= med.minSingleDose %></td>
                            <td><%= med.maxSingleDose %></td>
                            <td><%= med.maxDailyDose %></td>
                            <td>
                                <% if ("admin".equals(userRole) || "pharmacist".equals(userRole)) { %>
                                    <div class="btn-group">
                                        <button class="btn btn-secondary" onclick="viewDetails(<%= med.medicationId %>)">View</button>
                                        <button class="btn btn-danger" onclick="deleteMedication(<%= med.medicationId %>)">Delete</button>
                                    </div>
                                <% } else { %>
                                    <button class="btn btn-secondary" onclick="viewDetails(<%= med.medicationId %>)">View</button>
                                <% } %>
                            </td>
                        </tr>
                    <% }
                    } %>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add/Edit Medication Modal -->
    <div id="addMedicationModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Medication</h2>
                <span class="close" onclick="closeModal('addMedicationModal')">&times;</span>
            </div>
            <form method="POST" action="MedicationServlet">
                <input type="hidden" name="action" value="create">

                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Medication Name:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="genericName">Generic Name:</label>
                        <input type="text" id="genericName" name="genericName">
                    </div>
                </div>

                <div class="form-row-3">
                    <div class="form-group">
                        <label for="strength">Strength:</label>
                        <input type="text" id="strength" name="strength" placeholder="e.g., 500">
                    </div>
                    <div class="form-group">
                        <label for="unit">Unit:</label>
                        <select id="unit" name="unit">
                            <option value="mg">mg</option>
                            <option value="g">g</option>
                            <option value="mcg">mcg</option>
                            <option value="ml">ml</option>
                            <option value="units">units</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="manufacturer">Manufacturer:</label>
                        <input type="text" id="manufacturer" name="manufacturer">
                    </div>
                </div>

                <div class="form-row-3">
                    <div class="form-group">
                        <label for="minSingleDose">Min Single Dose:</label>
                        <input type="number" id="minSingleDose" name="minSingleDose" step="0.01">
                    </div>
                    <div class="form-group">
                        <label for="maxSingleDose">Max Single Dose:</label>
                        <input type="number" id="maxSingleDose" name="maxSingleDose" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="maxDailyDose">Max Daily Dose:</label>
                        <input type="number" id="maxDailyDose" name="maxDailyDose" step="0.01">
                    </div>
                </div>

                <div class="form-group">
                    <label for="sideEffects">Side Effects:</label>
                    <textarea id="sideEffects" name="sideEffects" rows="2"></textarea>
                </div>

                <div class="form-group">
                    <label for="contraindications">Contraindications:</label>
                    <textarea id="contraindications" name="contraindications" rows="2"></textarea>
                </div>

                <button type="submit" class="btn btn-success" style="width: 100%;">Save Medication</button>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).classList.add('show');
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }

        function viewDetails(medicationId) {
            alert('Medication ID: ' + medicationId);
        }

        function deleteMedication(medicationId) {
            if (confirm('Are you sure you want to delete this medication?')) {
                window.location.href = 'MedicationServlet?action=delete&medicationId=' + medicationId;
            }
        }

        window.onclick = function(event) {
            let modal = document.getElementById('addMedicationModal');
            if (event.target === modal) {
                modal.classList.remove('show');
            }
        }
    </script>
</body>
</html>
