<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.*" %>
<%
    // Check if user is logged in
    Integer userId = (Integer) session.getAttribute("userId");
    String username = (String) session.getAttribute("username");
    String userRole = (String) session.getAttribute("role");

    if (userId == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <span>Welcome, <%= username %> (<%= userRole %>)</span>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Dashboard</h2>
            
            <div class="dashboard-grid">
                <% if ("admin".equals(userRole)) { %>
                    <div class="stat-card">
                        <h3>Patients</h3>
                        <div class="number">--</div>
                        <a href="patients.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">Manage</a>
                    </div>
                    <div class="stat-card">
                        <h3>Doctors</h3>
                        <div class="number">--</div>
                        <a href="doctors.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">Manage</a>
                    </div>
                    <div class="stat-card">
                        <h3>Medications</h3>
                        <div class="number">--</div>
                        <a href="medications.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">Manage</a>
                    </div>
                    <div class="stat-card">
                        <h3>Prescriptions</h3>
                        <div class="number">--</div>
                        <a href="prescriptions.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                    <div class="stat-card">
                        <h3>Alerts</h3>
                        <div class="number">--</div>
                        <a href="alerts.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                    <div class="stat-card">
                        <h3>Metrics</h3>
                        <div class="number">--</div>
                        <a href="metrics.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                <% } else if ("doctor".equals(userRole)) { %>
                    <div class="stat-card">
                        <h3>My Patients</h3>
                        <div class="number">--</div>
                        <a href="my_patients.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                    <div class="stat-card">
                        <h3>Prescriptions</h3>
                        <div class="number">--</div>
                        <a href="my_prescriptions.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">Manage</a>
                    </div>
                    <div class="stat-card">
                        <h3>Create Prescription</h3>
                        <div class="number">+</div>
                        <a href="create_prescription.jsp" class="btn btn-success" style="margin-top: 1rem; display: block; text-align: center;">Create</a>
                    </div>
                <% } else if ("patient".equals(userRole)) { %>
                    <div class="stat-card">
                        <h3>My Prescriptions</h3>
                        <div class="number">--</div>
                        <a href="patient_prescriptions.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                    <div class="stat-card">
                        <h3>My Profile</h3>
                        <div class="number">📋</div>
                        <a href="patient_profile.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View/Edit</a>
                    </div>
                <% } else if ("pharmacist".equals(userRole)) { %>
                    <div class="stat-card">
                        <h3>Prescriptions</h3>
                        <div class="number">--</div>
                        <a href="pharmacist_prescriptions.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                    <div class="stat-card">
                        <h3>Medications</h3>
                        <div class="number">--</div>
                        <a href="medications.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">Manage</a>
                    </div>
                    <div class="stat-card">
                        <h3>Alerts</h3>
                        <div class="number">--</div>
                        <a href="alerts.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                <% } else if ("nurse".equals(userRole)) { %>
                    <div class="stat-card">
                        <h3>Patients</h3>
                        <div class="number">--</div>
                        <a href="nurse_patients.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                    <div class="stat-card">
                        <h3>Patient Vitals</h3>
                        <div class="number">📊</div>
                        <a href="patient_vitals.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">Monitor</a>
                    </div>
                    <div class="stat-card">
                        <h3>Alerts</h3>
                        <div class="number">--</div>
                        <a href="alerts.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">View</a>
                    </div>
                    <div class="stat-card">
                        <h3>Care Notes</h3>
                        <div class="number">📝</div>
                        <a href="care_notes.jsp" class="btn btn-primary" style="margin-top: 1rem; display: block; text-align: center;">Manage</a>
                    </div>
                <% } %>
            </div>

            <div style="background-color: #f7fafc; padding: 1.5rem; border-radius: 4px; margin-top: 2rem;">
                <h3>System Features</h3>
                <ul style="margin-top: 1rem; line-height: 2;">
                    <li>✓ Patient Management (CRUD)</li>
                    <li>✓ Doctor & Staff Management</li>
                    <li>✓ Medication Management</li>
                    <li>✓ Prescription Management</li>
                    <li>✓ Dosage Validation & Safety Checks</li>
                    <li>✓ Drug Interaction Detection</li>
                    <li>✓ Real-time Alerts & Warnings</li>
                    <li>✓ Audit Trail & Logging</li>
                    <li>✓ Role-Based Access Control</li>
                    <li>✓ Password Encryption</li>
                    <li>✓ Performance Metrics</li>
                </ul>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>
</body>
</html>
