<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.hospital.dao.PatientDAO.*,com.hospital.dao.PatientDAO,java.util.*,java.time.LocalDateTime,java.time.format.DateTimeFormatter" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String userRole = (String) session.getAttribute("role");
    
    if (userId == null) {
        response.sendRedirect("dashboard.jsp");
        return;
    }
    
    // Check if user is nurse
    if (!"nurse".equals(userRole)) {
        response.sendRedirect("dashboard.jsp");
        return;
    }

    String patientIdStr = request.getParameter("patientId");
    PatientDAO.Patient patient = null;
    if (patientIdStr != null && !patientIdStr.isEmpty()) {
        int patientId = Integer.parseInt(patientIdStr);
        patient = PatientDAO.getPatientById(patientId);
    }
    
    List<PatientDAO.Patient> patients = PatientDAO.getAllPatients();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Care Notes - Hospital Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .note-form {
            margin: 1.5rem 0;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 1rem;
        }
        .form-group label {
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .form-group textarea {
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: Arial, sans-serif;
        }
        .note-item {
            background-color: #f0f4f8;
            border-left: 4px solid #4a5568;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
        }
        .note-header {
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        .note-time {
            font-size: 0.9rem;
            color: #718096;
        }
        .note-content {
            margin-top: 0.75rem;
            color: #1a202c;
        }
    </style>
</head>
<body>
    <header>
        <h1>Hospital Management System</h1>
        <nav>
            <a href="dashboard.jsp">Dashboard</a>
            <a href="nurse_patients.jsp">Patients</a>
            <a href="patient_vitals.jsp">Patient Vitals</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>

    <div class="container">
        <div class="card">
            <h2>Patient Care Notes</h2>

            <% if (patient != null) { %>
                <div style="background-color: #f0f4f8; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem;">
                    <h3><%= patient.firstName %> <%= patient.lastName %></h3>
                    <p>Patient ID: <%= patient.patientId %> | DOB: <%= patient.dateOfBirth %> | Gender: <%= patient.gender %></p>
                    <p>Blood Group: <%= patient.bloodGroup %> | Phone: <%= patient.phone %></p>
                </div>

                <div class="note-form">
                    <h3>Add New Note</h3>
                    <form method="POST" action="#">
                        <div class="form-group">
                            <label for="noteType">Note Type</label>
                            <select id="noteType" name="noteType" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="observation">Patient Observation</option>
                                <option value="medication">Medication Administration</option>
                                <option value="procedure">Procedure</option>
                                <option value="incident">Incident Report</option>
                                <option value="general">General Note</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="content">Note Content</label>
                            <textarea id="content" name="content" rows="5" placeholder="Enter care note details..." required></textarea>
                        </div>

                        <div style="display: flex; gap: 1rem;">
                            <button type="submit" class="btn btn-success">Save Note</button>
                            <button type="button" class="btn btn-secondary" onclick="goBack()">Cancel</button>
                        </div>
                    </form>
                </div>

                <hr style="margin: 2rem 0;">

                <h3>Recent Notes</h3>
                <div class="note-item">
                    <div class="note-header">Patient Observation</div>
                    <div class="note-time">Today at 10:30 AM</div>
                    <div class="note-content">Patient is alert and responsive. Vital signs stable. Wound dressing changed successfully. Pain level 3/10.</div>
                </div>

                <div class="note-item">
                    <div class="note-header">Medication Administration</div>
                    <div class="note-time">Today at 09:00 AM</div>
                    <div class="note-content">Administered Amoxicillin 500mg as prescribed. Patient tolerated well without adverse effects.</div>
                </div>

                <div class="note-item">
                    <div class="note-header">General Note</div>
                    <div class="note-time">Yesterday at 14:30 PM</div>
                    <div class="note-content">Patient visited by family. Appeared comfortable and in good spirits. Encouraged to ambulate as tolerated.</div>
                </div>
            <% } else { %>
                <div style="margin: 1.5rem 0;">
                    <p style="margin-bottom: 1rem;">Select a patient to record care notes:</p>
                    <select id="patientSelect" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; width: 100%;">
                        <option value="">-- Select Patient --</option>
                        <% for (PatientDAO.Patient p : patients) { %>
                            <option value="<%= p.patientId %>"><%= p.firstName %> <%= p.lastName %> (ID: <%= p.patientId %>)</option>
                        <% } %>
                    </select>
                    <button class="btn btn-primary" style="margin-top: 1rem;" onclick="selectPatient()">Select</button>
                </div>
            <% } %>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h3>Care Notes Guidelines</h3>
            <ul style="margin-top: 1rem; line-height: 2;">
                <li><strong>Be Objective:</strong> Record facts, not interpretations</li>
                <li><strong>Be Specific:</strong> Use exact times, measurements, and patient statements</li>
                <li><strong>Be Concise:</strong> Write clearly without unnecessary details</li>
                <li><strong>Document Timely:</strong> Record notes as soon as possible after observations</li>
                <li><strong>Include Vital Signs:</strong> Record relevant vital sign measurements</li>
                <li><strong>Document Patient Response:</strong> Note how the patient reacted to care or medication</li>
                <li><strong>Report Abnormalities:</strong> Immediately document any unusual findings</li>
                <li><strong>Sign and Date:</strong> All entries should be properly signed and dated</li>
            </ul>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </footer>

    <script>
        function selectPatient() {
            const patientId = document.getElementById('patientSelect').value;
            if (patientId) {
                window.location.href = 'care_notes.jsp?patientId=' + patientId;
            } else {
                alert('Please select a patient');
            }
        }

        function goBack() {
            window.location.href = 'nurse_patients.jsp';
        }
    </script>
</body>
</html>
