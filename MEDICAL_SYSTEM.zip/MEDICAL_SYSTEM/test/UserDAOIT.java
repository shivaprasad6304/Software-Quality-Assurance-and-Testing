import com.hospital.dao.UserDAO;
import com.hospital.util.PasswordEncryption;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;

import static org.junit.Assert.*;

/**
 * Integration tests for UserDAO - tests database operations with real MySQL connection
 */
public class UserDAOIT extends TestBase {
    
    private static final String TEST_USERNAME = "testuser_" + System.currentTimeMillis();
    private static final String TEST_EMAIL = "test_" + System.currentTimeMillis() + "@test.com";
    private static final String TEST_PASSWORD = "TestPassword123";
    
    @Before
    public void setUp() {
        // Clean up test data before each test
        cleanUpTestData();
    }
    
    /**
     * Test: Register a new user successfully
     */
    @Test
    public void testRegisterUserSuccess() {
        boolean result = UserDAO.registerUser(TEST_USERNAME, TEST_PASSWORD, TEST_EMAIL, "patient");
        
        assertTrue("User registration should succeed", result);
        System.out.println("✅ testRegisterUserSuccess PASSED");
    }
    
    /**
     * Test: Cannot register duplicate username
     */
    @Test
    public void testRegisterUserDuplicateUsername() {
        UserDAO.registerUser(TEST_USERNAME, TEST_PASSWORD, TEST_EMAIL, "patient");
        
        // Try to register same username again
        boolean result = UserDAO.registerUser(TEST_USERNAME, "DifferentPassword123", "different@test.com", "doctor");
        
        assertFalse("Duplicate username registration should fail", result);
        System.out.println("✅ testRegisterUserDuplicateUsername PASSED");
    }
    
    /**
     * Test: Login with correct credentials
     */
    @Test
    public void testLoginUserSuccess() {
        UserDAO.registerUser(TEST_USERNAME, TEST_PASSWORD, TEST_EMAIL, "patient");
        
        UserDAO.User user = UserDAO.loginUser(TEST_USERNAME, TEST_PASSWORD);
        
        assertNotNull("User should be found", user);
        assertEquals("Username should match", TEST_USERNAME, user.username);
        assertEquals("Email should match", TEST_EMAIL, user.email);
        assertEquals("Role should be patient", "patient", user.role);
        assertTrue("User should be active", user.isActive);
        System.out.println("✅ testLoginUserSuccess PASSED");
    }
    
    /**
     * Test: Login fails with wrong password
     */
    @Test
    public void testLoginUserWrongPassword() {
        UserDAO.registerUser(TEST_USERNAME, TEST_PASSWORD, TEST_EMAIL, "patient");
        
        UserDAO.User user = UserDAO.loginUser(TEST_USERNAME, "WrongPassword123");
        
        assertNull("Login with wrong password should fail", user);
        System.out.println("✅ testLoginUserWrongPassword PASSED");
    }
    
    /**
     * Test: Login fails with non-existent username
     */
    @Test
    public void testLoginUserNonExistent() {
        UserDAO.User user = UserDAO.loginUser("nonexistent_user_xyz", TEST_PASSWORD);
        
        assertNull("Login with non-existent user should fail", user);
        System.out.println("✅ testLoginUserNonExistent PASSED");
    }
    
    /**
     * Test: Get user by ID
     */
    @Test
    public void testGetUserById() {
        UserDAO.registerUser(TEST_USERNAME, TEST_PASSWORD, TEST_EMAIL, "doctor");
        UserDAO.User registeredUser = UserDAO.loginUser(TEST_USERNAME, TEST_PASSWORD);
        
        assertNotNull("User should be registered", registeredUser);
        
        UserDAO.User retrievedUser = UserDAO.getUserById(registeredUser.userId);
        
        assertNotNull("User should be retrievable by ID", retrievedUser);
        assertEquals("Username should match", TEST_USERNAME, retrievedUser.username);
        assertEquals("Email should match", TEST_EMAIL, retrievedUser.email);
        System.out.println("✅ testGetUserById PASSED");
    }
    
    /**
     * Test: Get user by non-existent ID returns null
     */
    @Test
    public void testGetUserByIdNotFound() {
        UserDAO.User user = UserDAO.getUserById(99999);
        
        assertNull("Non-existent user should return null", user);
        System.out.println("✅ testGetUserByIdNotFound PASSED");
    }
    
    /**
     * Test: Password encryption security
     */
    @Test
    public void testPasswordEncryptionSecurity() {
        String password1 = "TestPassword123";
        String password2 = "TestPassword123";
        
        String encrypted1 = PasswordEncryption.encryptPassword(password1);
        String encrypted2 = PasswordEncryption.encryptPassword(password2);
        
        // Same password should produce different hashes due to different salt
        assertNotEquals("Same password should have different hashes (different salts)", 
                       encrypted1, encrypted2);
        
        // Both should verify correctly
        assertTrue("First password should verify", 
                  PasswordEncryption.verifyEncryptedPassword(password1, encrypted1));
        assertTrue("Second password should verify", 
                  PasswordEncryption.verifyEncryptedPassword(password2, encrypted2));
        
        System.out.println("✅ testPasswordEncryptionSecurity PASSED");
    }
    
    /**
     * Test: User roles are properly stored
     */
    @Test
    public void testUserRoles() {
        String[] roles = {"patient", "doctor", "pharmacist", "nurse", "admin"};
        
        for (String role : roles) {
            String username = "user_" + role + "_" + System.currentTimeMillis();
            boolean registered = UserDAO.registerUser(username, TEST_PASSWORD, 
                                                     "email_" + role + "@test.com", role);
            assertTrue("User with role " + role + " should register", registered);
            
            UserDAO.User user = UserDAO.loginUser(username, TEST_PASSWORD);
            assertNotNull("User with role " + role + " should login", user);
            assertEquals("Role should be " + role, role, user.role);
        }
        
        System.out.println("✅ testUserRoles PASSED");
    }
}
