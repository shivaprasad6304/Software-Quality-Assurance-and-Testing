import com.hospital.util.DBConnection;
import java.sql.Connection;
import java.sql.Statement;
import java.util.*;

/**
 * Base class for all integration tests - provides common setup, teardown, and helper methods
 */
public abstract class TestBase {

    /**
     * Clean up test data from database
     */
    protected void cleanUpTestData() {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();

            // Clean up test data created during tests
            stmt.execute("DELETE FROM prescriptions WHERE patient_id IN (SELECT patient_id FROM patients WHERE first_name LIKE 'Test%')");
            stmt.execute("DELETE FROM patient_vitals WHERE patient_id IN (SELECT patient_id FROM patients WHERE first_name LIKE 'Test%')");
            stmt.execute("DELETE FROM patients WHERE first_name LIKE 'Test%'");
            stmt.execute("DELETE FROM doctors WHERE user_id IN (SELECT user_id FROM users WHERE username LIKE 'test%' OR username LIKE 'sysdoctor%' OR username LIKE 'sysnurse%')");
            stmt.execute("DELETE FROM users WHERE username LIKE 'test%' OR username LIKE 'sysdoctor%' OR username LIKE 'sysnurse%' OR username LIKE 'syspatient%' OR username LIKE 'syspharmacist%' OR username LIKE 'servlet_test%' OR username LIKE 'workflow%'");

            stmt.close();
            DBConnection.closeConnection(conn);
        } catch (Exception e) {
            // Ignore cleanup errors
            e.printStackTrace();
        }
    }

    /**
     * Create a test HTTP servlet request
     */
    protected MockRequest createRequest() {
        return new MockRequest();
    }

    /**
     * Create a test HTTP servlet response
     */
    protected MockResponse createResponse() {
        return new MockResponse();
    }

    /**
     * Create a test HTTP session
     */
    protected MockSession createSession() {
        return new MockSession();
    }

    /**
     * Mock implementation of HttpServletRequest
     */
    public static class MockRequest {
        private Map<String, String> parameters = new HashMap<>();
        private MockSession session = new MockSession();

        public String getParameter(String name) {
            return parameters.get(name);
        }

        public void setParameter(String name, String value) {
            parameters.put(name, value);
        }

        public MockSession getSession() {
            return session;
        }

        public void setSession(MockSession session) {
            this.session = session;
        }

        public String getMethod() {
            return "POST";
        }

        public String getRequestURI() {
            return "/medical-system/register";
        }
    }

    /**
     * Mock implementation of HttpServletResponse
     */
    public static class MockResponse {
        public String redirect;
        private java.io.StringWriter output = new java.io.StringWriter();
        private java.io.PrintWriter writer;

        public void sendRedirect(String location) throws java.io.IOException {
            redirect = location;
        }

        public String getRedirect() {
            return redirect;
        }

        public java.io.PrintWriter getWriter() throws java.io.IOException {
            if (writer == null) {
                writer = new java.io.PrintWriter(output);
            }
            return writer;
        }

        public String getOutput() {
            if (writer != null) {
                writer.flush();
            }
            return output.toString();
        }
    }

    /**
     * Mock implementation of HttpSession
     */
    public static class MockSession {
        private Map<String, Object> attributes = new HashMap<>();
        private boolean invalidated = false;

        public Object getAttribute(String name) {
            return attributes.get(name);
        }

        public void setAttribute(String name, Object value) {
            attributes.put(name, value);
        }

        public void removeAttribute(String name) {
            attributes.remove(name);
        }

        public void invalidate() {
            invalidated = true;
            attributes.clear();
        }

        public boolean isInvalidated() {
            return invalidated;
        }

        public String getId() {
            return "mock_session_" + System.currentTimeMillis();
        }
    }
}
