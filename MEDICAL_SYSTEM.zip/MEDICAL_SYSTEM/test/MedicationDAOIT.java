import com.hospital.dao.MedicationDAO;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;

import static org.junit.Assert.*;

/**
 * Integration tests for MedicationDAO - tests medication management operations
 */
public class MedicationDAOIT extends TestBase {
    
    private static final String TEST_MED_PREFIX = "TESTMED_" + System.currentTimeMillis() + "_";
    
    @Before
    public void setUp() {
        cleanUpTestData();
    }
    
    /**
     * Test: Create a medication successfully
     */
    @Test
    public void testCreateMedicationSuccess() {
        String medName = TEST_MED_PREFIX + "Aspirin";
        int medicationId = MedicationDAO.createMedication(
            medName,
            "Acetylsalicylic Acid",
            "500mg",
            "mg",
            "PharmaCorp",
            4000.0,      // maxDailyDose in mg
            500.0,       // minSingleDose in mg
            1000.0,      // maxSingleDose in mg
            "Bleeding, Nausea",
            "Warfarin, Ibuprofen"
        );
        
        assertTrue("Medication ID should be positive", medicationId > 0);
        System.out.println("✅ testCreateMedicationSuccess PASSED - Medication ID: " + medicationId);
    }
    
    /**
     * Test: Get medication by ID
     */
    @Test
    public void testGetMedicationById() {
        String medName = TEST_MED_PREFIX + "Paracetamol";
        int medicationId = MedicationDAO.createMedication(
            medName,
            "Acetaminophen",
            "500mg",
            "mg",
            "MediCorp",
            3000.0,      // maxDailyDose
            250.0,       // minSingleDose
            1000.0,      // maxSingleDose
            "Liver damage at high doses",
            "NSAIDs"
        );
        
        MedicationDAO.Medication medication = MedicationDAO.getMedicationById(medicationId);
        
        assertNotNull("Medication should be found", medication);
        assertEquals("Name should match", medName, medication.name);
        assertEquals("Generic name should match", "Acetaminophen", medication.genericName);
        System.out.println("✅ testGetMedicationById PASSED");
    }
    
    /**
     * Test: Get all medications
     */
    @Test
    public void testGetAllMedications() {
        // Create multiple medications
        for (int i = 0; i < 3; i++) {
            MedicationDAO.createMedication(
                TEST_MED_PREFIX + "Med" + i,
                "Generic" + i,
                "100mg",
                "mg",
                "Pharma" + i,
                1000.0 + i,  // maxDailyDose
                100.0 + i,   // minSingleDose
                500.0 + i,   // maxSingleDose
                "Side effect " + i,
                "Contraindication " + i
            );
        }
        
        java.util.List<MedicationDAO.Medication> medications = MedicationDAO.getAllMedications();
        
        assertNotNull("Medication list should not be null", medications);
        assertTrue("Should have at least 3 medications", medications.size() >= 3);
        System.out.println("✅ testGetAllMedications PASSED - Total medications: " + medications.size());
    }
    
    /**
     * Test: Delete medication
     */
    @Test
    public void testDeleteMedication() {
        String medName = TEST_MED_PREFIX + "DeleteMe";
        int medicationId = MedicationDAO.createMedication(
            medName,
            "ToBeDeleted",
            "100mg",
            "mg",
            "DeleteCorp",
            1000.0,      // maxDailyDose
            100.0,       // minSingleDose
            500.0,       // maxSingleDose
            "None",
            "None"
        );
        
        boolean result = MedicationDAO.deleteMedication(medicationId);
        assertTrue("Delete should succeed", result);
        
        MedicationDAO.Medication deletedMed = MedicationDAO.getMedicationById(medicationId);
        assertNull("Deleted medication should not be found", deletedMed);
        System.out.println("✅ testDeleteMedication PASSED");
    }
    
    /**
     * Test: Medication strength formats
     */
    @Test
    public void testMedicationStrengths() {
        String[] strengths = {"100mg", "250mg", "500mg", "1000mg", "5ml", "10ml"};
        double[] doses = {1000.0, 2000.0, 3000.0, 4000.0, 5000.0, 6000.0};
        
        for (int i = 0; i < strengths.length; i++) {
            String medName = TEST_MED_PREFIX + "Strength" + i;
            int medicationId = MedicationDAO.createMedication(
                medName,
                "Generic" + i,
                strengths[i],
                "unit" + i,
                "Pharma",
                doses[i],           // maxDailyDose
                doses[i] / 10,      // minSingleDose
                doses[i] / 2,       // maxSingleDose
                "Side effects",
                "Contraindications"
            );
            
            MedicationDAO.Medication med = MedicationDAO.getMedicationById(medicationId);
            assertEquals("Strength should be " + strengths[i], strengths[i], med.strength);
        }
        
        System.out.println("✅ testMedicationStrengths PASSED");
    }
    
    /**
     * Test: Medication manufacturers
     */
    @Test
    public void testMedicationManufacturers() {
        String[] manufacturers = {
            "Pfizer Inc",
            "Novartis AG",
            "Johnson & Johnson",
            "Merck & Co",
            "Roche Holding",
            "AbbVie Inc"
        };
        
        for (int i = 0; i < manufacturers.length; i++) {
            String medName = TEST_MED_PREFIX + "Manu" + i;
            int medicationId = MedicationDAO.createMedication(
                medName,
                "Generic" + i,
                "100mg",
                "mg",
                manufacturers[i],
                1000.0 + i,  // maxDailyDose
                100.0 + i,   // minSingleDose
                500.0 + i,   // maxSingleDose
                "Side effects",
                "Contraindications"
            );
            
            MedicationDAO.Medication med = MedicationDAO.getMedicationById(medicationId);
            assertEquals("Manufacturer should be " + manufacturers[i], 
                        manufacturers[i], med.manufacturer);
        }
        
        System.out.println("✅ testMedicationManufacturers PASSED");
    }

    /**
     * Test: Medication dosage ranges
     */
    @Test
    public void testMedicationDosageRanges() {
        String medName = TEST_MED_PREFIX + "Dosage";
        int medicationId = MedicationDAO.createMedication(
            medName,
            "TestGeneric",
            "500mg",
            "mg",
            "DosagePharm",
            4000.0,      // maxDailyDose
            500.0,       // minSingleDose
            2000.0,      // maxSingleDose
            "May cause drowsiness",
            "Do not use with alcohol"
        );
        
        MedicationDAO.Medication med = MedicationDAO.getMedicationById(medicationId);
        assertNotNull("Medication should exist", med);
        assertTrue("Max daily dose should be positive", med.maxDailyDose > 0);
        assertTrue("Min single dose should be less than max single dose", 
                  med.minSingleDose < med.maxSingleDose);
        System.out.println("✅ testMedicationDosageRanges PASSED");
    }

    /**
     * Test: Side effects recording
     */
    @Test
    public void testMedicationSideEffects() {
        String sideEffects = "Headache, Nausea, Dizziness, Rash";
        String medName = TEST_MED_PREFIX + "SideEffect";
        int medicationId = MedicationDAO.createMedication(
            medName,
            "EffectGeneric",
            "200mg",
            "mg",
            "EffectPharm",
            2000.0,      // maxDailyDose
            200.0,       // minSingleDose
            1000.0,      // maxSingleDose
            sideEffects,
            "None"
        );
        
        MedicationDAO.Medication med = MedicationDAO.getMedicationById(medicationId);
        assertNotNull("Medication should have side effects", med.sideEffects);
        assertTrue("Side effects should contain Nausea", med.sideEffects.contains("Nausea"));
        System.out.println("✅ testMedicationSideEffects PASSED");
    }

    /**
     * Test: Contraindications
     */
    @Test
    public void testMedicationContraindications() {
        String contraindications = "Pregnancy, Renal failure, Liver disease";
        String medName = TEST_MED_PREFIX + "Contraind";
        int medicationId = MedicationDAO.createMedication(
            medName,
            "ContrainGeneric",
            "250mg",
            "mg",
            "ContrainPharm",
            3000.0,      // maxDailyDose
            250.0,       // minSingleDose
            1500.0,      // maxSingleDose
            "Dizziness",
            contraindications
        );
        
        MedicationDAO.Medication med = MedicationDAO.getMedicationById(medicationId);
        assertNotNull("Medication should have contraindications", med.contraindications);
        assertTrue("Contraindications should mention Pregnancy", 
                  med.contraindications.contains("Pregnancy"));
        System.out.println("✅ testMedicationContraindications PASSED");
    }
    
    /**
     * Test: Non-existent medication returns null
     */
    @Test
    public void testGetNonExistentMedication() {
        MedicationDAO.Medication med = MedicationDAO.getMedicationById(99999);
        
        assertNull("Non-existent medication should return null", med);
        System.out.println("✅ testGetNonExistentMedication PASSED");
    }
    
    /**
     * Test: Medication active status
     */
    @Test
    public void testMedicationActiveStatus() {
        String medName = TEST_MED_PREFIX + "Active";
        int medicationId = MedicationDAO.createMedication(
            medName,
            "ActiveGeneric",
            "100mg",
            "mg",
            "ActivePharm",
            1000.0,      // maxDailyDose
            100.0,       // minSingleDose
            500.0,       // maxSingleDose
            "None",
            "None"
        );
        
        MedicationDAO.Medication med = MedicationDAO.getMedicationById(medicationId);
        assertNotNull("Medication should be created", med);
        // Most systems default to active
        System.out.println("✅ testMedicationActiveStatus PASSED");
    }
}
