import com.hospital.dao.UserDAO;
import com.hospital.dao.PatientDAO;
import com.hospital.dao.DoctorDAO;
import com.hospital.dao.MedicationDAO;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;

import static org.junit.Assert.*;

/**
 * System Integration Tests - end-to-end workflows with role-based access
 */
public class SystemIntegrationTestsIT extends TestBase {
    
    private static final String PATIENT_USERNAME = "syspatient_" + System.currentTimeMillis();
    private static final String DOCTOR_USERNAME = "sysdoctor_" + System.currentTimeMillis();
    private static final String PHARMACIST_USERNAME = "syspharmacist_" + System.currentTimeMillis();
    private static final String TEST_PASSWORD = "TestPassword123";
    
    private int patientUserId;
    private int patientId;
    private int doctorUserId;
    private int doctorId;
    private int pharmacistUserId;
    
    @Before
    public void setUp() {
        cleanUpTestData();
        setupTestUsers();
    }
    
    /**
     * Test: Complete patient registration and profile creation workflow
     */
    @Test
    public void testPatientRegistrationWorkflow() {
        // 1. Register patient with unique timestamp
        long timestamp = System.currentTimeMillis();
        String username = "workflow_pat_" + timestamp;
        boolean registered = UserDAO.registerUser(
            username,
            TEST_PASSWORD,
            "workflow.patient" + timestamp + "@test.com",
            "patient"
        );
        assertTrue("Patient registration should succeed", registered);
        
        // 2. Login as patient
        UserDAO.User patientUser = UserDAO.loginUser(username, TEST_PASSWORD);
        assertNotNull("Patient should be able to login", patientUser);
        assertEquals("User role should be patient", "patient", patientUser.role);
        
        // 3. Create patient profile
        int newPatientId = PatientDAO.createPatient(
            patientUser.userId,
            "John",
            "Doe",
            "1990-01-15",
            "Male",
            "9999999999",
            "123 Main St",
            "O+",
            "None",
            "None"
        );
        
        // 4. Verify patient profile
        PatientDAO.Patient profile = PatientDAO.getPatientById(newPatientId);
        assertNotNull("Patient profile should be created", profile);
        assertEquals("First name should match", "John", profile.firstName);
        
        System.out.println("✅ testPatientRegistrationWorkflow PASSED");
    }
    
    /**
     * Test: Complete doctor registration and credentials workflow
     */
    @Test
    public void testDoctorRegistrationWorkflow() {
        // 1. Register doctor
        String username = "workflow_doc_" + System.currentTimeMillis();
        boolean registered = UserDAO.registerUser(username, TEST_PASSWORD, "doc@test.com", "doctor");
        assertTrue("Doctor registration should succeed", registered);
        
        // 2. Login as doctor
        UserDAO.User doctor = UserDAO.loginUser(username, TEST_PASSWORD);
        assertNotNull("Doctor should login", doctor);
        assertEquals("Role should be doctor", "doctor", doctor.role);
        
        // 3. Create doctor profile
        int newDoctorId = DoctorDAO.createDoctor(
            doctor.userId,
            "Dr. Jane",
            "Smith",
            "Cardiology",
            "LIC001234",
            "8888888888",
            "jane.smith@hospital.com"
        );
        
        // 4. Verify doctor profile
        DoctorDAO.Doctor profile = DoctorDAO.getDoctorById(newDoctorId);
        assertNotNull("Doctor profile should be created", profile);
        assertEquals("Specialization should match", "Cardiology", profile.specialization);
        
        System.out.println("✅ testDoctorRegistrationWorkflow PASSED");
    }
    
    /**
     * Test: Role-based access control - only doctors can view all patients
     */
    @Test
    public void testRoleBasedAccessControl_DoctorViewPatients() {
        // Setup: Create doctor and multiple patients
        UserDAO.User doctor = UserDAO.loginUser(DOCTOR_USERNAME, TEST_PASSWORD);
        UserDAO.User patient = UserDAO.loginUser(PATIENT_USERNAME, TEST_PASSWORD);
        
        assertNotNull("Doctor should exist", doctor);
        assertNotNull("Patient should exist", patient);
        
        assertEquals("Doctor role should be verified", "doctor", doctor.role);
        assertEquals("Patient role should be verified", "patient", patient.role);
        
        // Doctor can view all patients
        java.util.List<PatientDAO.Patient> allPatients = PatientDAO.getAllPatients();
        assertNotNull("Doctor should get patient list", allPatients);
        assertTrue("Should have at least 1 patient", allPatients.size() >= 1);
        
        System.out.println("✅ testRoleBasedAccessControl_DoctorViewPatients PASSED");
    }
    
    /**
     * Test: Medication management workflow
     */
    @Test
    public void testMedicationManagementWorkflow() {
        // 1. Create medications with correct parameters
        int med1 = MedicationDAO.createMedication(
            "Workflow_Med1_" + System.currentTimeMillis(),
            "Generic1",
            "500mg",
            "mg",
            "PharmaCorp",
            2000.0,      // maxDailyDose
            500.0,       // minSingleDose
            1000.0,      // maxSingleDose
            "Nausea",
            "None"
        );
        
        int med2 = MedicationDAO.createMedication(
            "Workflow_Med2_" + System.currentTimeMillis(),
            "Generic2",
            "250mg",
            "mg",
            "PharmaCorp",
            1500.0,      // maxDailyDose
            250.0,       // minSingleDose
            750.0,       // maxSingleDose
            "Headache",
            "None"
        );
        
        // 2. Retrieve medications
        MedicationDAO.Medication medication1 = MedicationDAO.getMedicationById(med1);
        MedicationDAO.Medication medication2 = MedicationDAO.getMedicationById(med2);
        
        assertNotNull("First medication should exist", medication1);
        assertNotNull("Second medication should exist", medication2);
        
        // 3. Verify all medications can be retrieved
        java.util.List<MedicationDAO.Medication> allMeds = MedicationDAO.getAllMedications();
        assertTrue("Should have at least 2 medications", allMeds.size() >= 2);
        
        System.out.println("✅ testMedicationManagementWorkflow PASSED");
    }
    
    /**
     * Test: Patient allergies impact on medication safety
     */
    @Test
    public void testPatientAllergyManagement() {
        // Patient with specific allergies
        int allergyPatientId = PatientDAO.createPatient(
            patientUserId,
            "Allergy",
            "Patient",
            "1988-05-20",
            "Male",
            "6666666666",
            "Allergy Ave",
            "A+",
            "Penicillin, Sulfa",
            "None"
        );
        
        PatientDAO.Patient patient = PatientDAO.getPatientById(allergyPatientId);
        assertNotNull("Patient with allergies should exist", patient);
        assertTrue("Allergies should contain Penicillin", patient.allergies.contains("Penicillin"));
        
        // Medication should be available but flagged as contraindicated
        int medId = MedicationDAO.createMedication(
            "Allergy_Med_" + System.currentTimeMillis(),
            
            500000.0,    // minSingleDose in units
            2000000.0,   // maxSingleDose in units
            "500000 units",
            "units",
            "PharmaCorp",
            "Four times daily",
            "Allergic reactions",
            "Penicillin allergy"
        );
        
        MedicationDAO.Medication med = MedicationDAO.getMedicationById(medId);
        assertNotNull("Medication should exist", med);
        
        System.out.println("✅ testPatientAllergyManagement PASSED");
    }
    
    /**
     * Test: Doctor-patient relationship workflow
     */
    @Test
    public void testDoctorPatientRelationship() {
        // 1. Doctor and patient exist
        UserDAO.User doctor = UserDAO.loginUser(DOCTOR_USERNAME, TEST_PASSWORD);
        UserDAO.User patient = UserDAO.loginUser(PATIENT_USERNAME, TEST_PASSWORD);
        
        assertNotNull("Doctor should exist", doctor);
        assertNotNull("Patient should exist", patient);
        
        // 2. Get doctor and patient profiles
        DoctorDAO.Doctor doctorProfile = DoctorDAO.getDoctorById(doctorId);
        PatientDAO.Patient patientProfile = PatientDAO.getPatientById(patientId);
        
        assertNotNull("Doctor profile should exist", doctorProfile);
        assertNotNull("Patient profile should exist", patientProfile);
        
        // 3. Doctor can view patient
        PatientDAO.Patient viewedPatient = PatientDAO.getPatientById(patientProfile.patientId);
        assertNotNull("Doctor should be able to view patient", viewedPatient);
        
        System.out.println("✅ testDoctorPatientRelationship PASSED");
    }
    
    /**
     * Test: Multi-role access patterns
     */
    @Test
    public void testMultiRoleAccessPatterns() {
        // 1. Patient accesses own profile
        PatientDAO.Patient ownPatient = PatientDAO.getPatientByUserId(patientUserId);
        assertNotNull("Patient should access own profile", ownPatient);
        
        // 2. Doctor accesses patient profiles
        java.util.List<PatientDAO.Patient> patientList = PatientDAO.getAllPatients();
        assertTrue("Doctor should view patient list", patientList.size() >= 1);
        
        // 3. Doctor profile accessible to doctors
        DoctorDAO.Doctor docProfile = DoctorDAO.getDoctorById(doctorId);
        assertNotNull("Doctor profile should be accessible", docProfile);
        
        // 4. All doctors should be retrievable
        java.util.List<DoctorDAO.Doctor> doctorList = DoctorDAO.getAllDoctors();
        assertTrue("Doctor list should be available", doctorList.size() >= 1);
        
        System.out.println("✅ testMultiRoleAccessPatterns PASSED");
    }
    
    /**
     * Test: Medication substitution workflow
     */
    @Test
    public void testMedicationSubstitutionWorkflow() {
        // Create similar medications
        int med1 = MedicationDAO.createMedication(
            "Original_Med_" + System.currentTimeMillis(),
            "ActiveSubstance1",
            "500mg",
            "mg",
            "Pharma1",
            2000.0,      // maxDailyDose
            500.0,       // minSingleDose
            1000.0,      // maxSingleDose
            "Minor side effects",
            "None"
        );
        
        int substitute = MedicationDAO.createMedication(
            "Substitute_Med_" + System.currentTimeMillis(),
            "ActiveSubstance1",
            "500mg",
            "mg",
            "Pharma2",
            2000.0,      // maxDailyDose
            500.0,       // minSingleDose
            1000.0,      // maxSingleDose
            "Minor side effects",
            "None"
        );
        
        assertNotNull("Medications should be created", med1);
        assertNotNull("Substitute medication should be created", substitute);
        assertEquals("Both should have same generic", "ActiveSubstance1", 
                    MedicationDAO.getMedicationById(med1).genericName);
        System.out.println("✅ testMedicationSubstitutionWorkflow PASSED");
    }
    
    /**
     * Test: Data integrity across related entities
     */
    @Test
    public void testDataIntegrity() {
        // 1. User exists
        UserDAO.User user = UserDAO.getUserById(patientUserId);
        assertNotNull("User should exist", user);
        
        // 2. Patient linked to user
        PatientDAO.Patient patient = PatientDAO.getPatientByUserId(patientUserId);
        assertNotNull("Patient should be linked to user", patient);
        assertEquals("Patient user ID should match", patientUserId, patient.userId);
        
        // 3. Patient can be retrieved by ID
        PatientDAO.Patient patientById = PatientDAO.getPatientById(patient.patientId);
        assertNotNull("Patient should be retrievable by ID", patientById);
        assertEquals("Patient data should be consistent", patient.firstName, patientById.firstName);
        
        System.out.println("✅ testDataIntegrity PASSED");
    }
    
    /**
     * Test: Update and modification workflows
     */
    @Test
    public void testUpdateWorkflow() {
        // 1. Get patient
        PatientDAO.Patient patient = PatientDAO.getPatientById(patientId);
        String originalPhone = patient.phone;
        
        // 2. Update patient info
        boolean updated = PatientDAO.updatePatient(
            patientId,
            patient.firstName,
            patient.lastName,
          
            patient.gender,
            "9111111111",  // New phone
            patient.address,
            patient.bloodGroup,
            patient.allergies,
            patient.medicalHistory
        );
        
        assertTrue("Update should succeed", updated);
        
        // 3. Verify update
        PatientDAO.Patient updatedPatient = PatientDAO.getPatientById(patientId);
        assertEquals("Phone should be updated", "9111111111", updatedPatient.phone);
        assertNotEquals("Phone should have changed", originalPhone, updatedPatient.phone);
        
        System.out.println("✅ testUpdateWorkflow PASSED");
    }
    
    private void setupTestUsers() {
        try {
            // Create patient user and profile
            UserDAO.registerUser(PATIENT_USERNAME, TEST_PASSWORD, "patient@test.com", "patient");
            UserDAO.User patient = UserDAO.loginUser(PATIENT_USERNAME, TEST_PASSWORD);
            patientUserId = patient.userId;
            
            patientId = PatientDAO.createPatient(
                patientUserId,
                "Test",
                "Patient",
                "1990-01-01",
                "Male",
                "9000000001",
                "Patient Street",
                "O+",
                "None",
                "None"
            );
            
            // Create doctor user and profile
            UserDAO.registerUser(DOCTOR_USERNAME, TEST_PASSWORD, "doctor@test.com", "doctor");
            UserDAO.User doctor = UserDAO.loginUser(DOCTOR_USERNAME, TEST_PASSWORD);
            doctorUserId = doctor.userId;
            
            doctorId = DoctorDAO.createDoctor(
                doctorUserId,
                "Dr. Test",
                "Doctor",
                "General",
                "LIC000001",
                "8000000001",
                "doctor@hospital.com"
            );
            
            // Create pharmacist user
            UserDAO.registerUser(PHARMACIST_USERNAME, TEST_PASSWORD, "pharm@test.com", "pharmacist");
            UserDAO.User pharmacist = UserDAO.loginUser(PHARMACIST_USERNAME, TEST_PASSWORD);
            pharmacistUserId = pharmacist.userId;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void cleanUpTestData() {
        try {
            Connection conn = com.hospital.util.DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            
            // Delete test data
            stmt.execute("DELETE FROM patients WHERE user_id IN (SELECT user_id FROM users WHERE username LIKE 'sys%' OR username LIKE 'workflow%')");
            stmt.execute("DELETE FROM doctors WHERE user_id IN (SELECT user_id FROM users WHERE username LIKE 'sys%' OR username LIKE 'workflow%')");
            stmt.execute("DELETE FROM users WHERE username LIKE 'sys%' OR username LIKE 'workflow%'");
            stmt.execute("DELETE FROM medications WHERE name LIKE 'Workflow_%' OR name LIKE 'Allergy_%' OR name LIKE 'Original_%' OR name LIKE 'Substitute_%'");
            
            stmt.close();
            com.hospital.util.DBConnection.closeConnection(conn);
        } catch (Exception e) {
            // Ignore cleanup errors
        }
    }
}
