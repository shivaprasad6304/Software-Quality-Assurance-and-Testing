/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LogoutServletIT {
    private LogoutServlet servlet;
    
    @BeforeEach
    public void setUp() {
        servlet = new LogoutServlet();
    }

    @Test
    public void testLogoutServletExists() {
        assertNotNull(servlet, "LogoutServlet should be instantiated");
    }

    @Test
    public void testLogoutServletIsNotNull() {
        LogoutServlet instance = new LogoutServlet();
        assertNotNull(instance);
    }
    
}
