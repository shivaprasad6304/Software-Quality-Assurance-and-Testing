import com.hospital.dao.UserDAO;
import com.hospital.dao.PatientDAO;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;

import static org.junit.Assert.*;

/**
 * Integration tests for PatientDAO - tests patient management operations
 */
public class PatientDAOIT extends TestBase {
    
    private int testUserId;
    private static final String TEST_USERNAME = "testpatient_" + System.currentTimeMillis();
    private static final String TEST_PASSWORD = "TestPassword123";
    
    @Before
    public void setUp() {
        cleanUpTestData();
        
        // Create a test user to associate with patient
        UserDAO.registerUser(TEST_USERNAME, TEST_PASSWORD, "patient@test.com", "patient");
        UserDAO.User user = UserDAO.loginUser(TEST_USERNAME, TEST_PASSWORD);
        testUserId = user.userId;
    }
    
    /**
     * Test: Create a patient successfully
     */
    @Test
    public void testCreatePatientSuccess() {
        int patientId = PatientDAO.createPatient(
            testUserId,
            "John",
            "Doe",
            "1990-01-15",
            "Male",
            "9999999999",
            "123 Main St",
            "O+",
            "Penicillin",
            "None"
        );
        
        assertTrue("Patient ID should be positive", patientId > 0);
        System.out.println("✅ testCreatePatientSuccess PASSED - Patient ID: " + patientId);
    }
    
    /**
     * Test: Get patient by ID
     */
    @Test
    public void testGetPatientById() {
        int patientId = PatientDAO.createPatient(
            testUserId,
            "Jane",
            "Smith",
            "1985-06-20",
            "Female",
            "8888888888",
            "456 Oak Ave",
            "AB-",
            "Aspirin",
            "Diabetes"
        );
        
        PatientDAO.Patient patient = PatientDAO.getPatientById(patientId);
        
        assertNotNull("Patient should be found", patient);
        assertEquals("First name should match", "Jane", patient.firstName);
        assertEquals("Last name should match", "Smith", patient.lastName);
        assertEquals("Blood group should match", "AB-", patient.bloodGroup);
        System.out.println("✅ testGetPatientById PASSED");
    }
    
    /**
     * Test: Get patient by user ID
     */
    @Test
    public void testGetPatientByUserId() {
        int patientId = PatientDAO.createPatient(
            testUserId,
            "Bob",
            "Johnson",
            "1992-03-10",
            "Male",
            "7777777777",
            "789 Pine Rd",
            "B+",
            "None",
            "Hypertension"
        );
        
        PatientDAO.Patient patient = PatientDAO.getPatientByUserId(testUserId);
        
        assertNotNull("Patient should be found by user ID", patient);
        assertEquals("User ID should match", testUserId, patient.userId);
        System.out.println("✅ testGetPatientByUserId PASSED");
    }
    
    /**
     * Test: Update patient information
     */
    @Test
    public void testUpdatePatient() {
        int patientId = PatientDAO.createPatient(
            testUserId,
            "Alice",
            "Brown",
            "1988-07-25",
            "Female",
            "6666666666",
            "321 Elm St",
            "O-",
            "Ibuprofen",
            "None"
        );
        
        // Update phone number
        boolean result = PatientDAO.updatePatient(
            patientId,
            "Alice",
            "Brown",
            "1988-07-25",
            "Female",
            "5555555555",  // Changed phone
            "321 Elm St",
            "O-",
            "Ibuprofen, Aspirin",  // Added aspirin to allergies
            "None"
        );
        
        assertTrue("Update should succeed", result);
        
        PatientDAO.Patient updatedPatient = PatientDAO.getPatientById(patientId);
        assertEquals("Phone should be updated", "5555555555", updatedPatient.phone);
        System.out.println("✅ testUpdatePatient PASSED");
    }
    
    /**
     * Test: Delete patient
     */
    @Test
    public void testDeletePatient() {
        int patientId = PatientDAO.createPatient(
            testUserId,
            "Tom",
            "Wilson",
            "1995-11-05",
            "Male",
            "4444444444",
            "654 Maple Dr",
            "AB+",
            "None",
            "None"
        );
        
        boolean result = PatientDAO.deletePatient(patientId);
        assertTrue("Delete should succeed", result);
        
        PatientDAO.Patient deletedPatient = PatientDAO.getPatientById(patientId);
        assertNull("Deleted patient should not be found", deletedPatient);
        System.out.println("✅ testDeletePatient PASSED");
    }
    
    /**
     * Test: Get all patients
     */
    @Test
    public void testGetAllPatients() {
        // Create multiple patients
        PatientDAO.createPatient(testUserId, "Patient1", "One", "1990-01-01",
                                "Male", "1111111111", "Addr1", "O+", "None", "None");
        
        // Get all patients
        java.util.List<PatientDAO.Patient> patients = PatientDAO.getAllPatients();
        
        assertNotNull("Patient list should not be null", patients);
        assertTrue("Should have at least 1 patient", patients.size() >= 1);
        System.out.println("✅ testGetAllPatients PASSED - Total patients: " + patients.size());
    }
    
    /**
     * Test: Patient allergies handling
     */
    @Test
    public void testPatientAllergies() {
        int patientId = PatientDAO.createPatient(
            testUserId,
            "Allergy",
            "Patient",
            "1993-05-15",
            "Female",
            "3333333333",
            "999 Test Lane",
            "A+",
            "Penicillin, Sulfa, Latex",
            "None"
        );
        
        PatientDAO.Patient patient = PatientDAO.getPatientById(patientId);
        assertNotNull("Patient should have allergies recorded", patient.allergies);
        assertTrue("Allergies should contain Penicillin", patient.allergies.contains("Penicillin"));
        System.out.println("✅ testPatientAllergies PASSED");
    }
    
    /**
     * Test: Medical history tracking
     */
    @Test
    public void testMedicalHistory() {
        int patientId = PatientDAO.createPatient(
            testUserId,
            "History",
            "Patient",
            "1980-12-20",
            "Male",
            "2222222222",
            "555 History Ave",
            "O-",
            "None",
            "Diabetes, Hypertension, Asthma"
        );
        
        PatientDAO.Patient patient = PatientDAO.getPatientById(patientId);
        assertNotNull("Medical history should be recorded", patient.medicalHistory);
        assertTrue("History should mention Diabetes", patient.medicalHistory.contains("Diabetes"));
        System.out.println("✅ testMedicalHistory PASSED");
    }
    
    /**
     * Test: Blood group validation
     */
    @Test
    public void testBloodGroupTypes() {
        String[] bloodGroups = {"O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"};
        
        for (int i = 0; i < bloodGroups.length; i++) {
            UserDAO.registerUser("patient_bg_" + i + "_" + System.currentTimeMillis(), 
                               TEST_PASSWORD, "email" + i + "@test.com", "patient");
            UserDAO.User user = UserDAO.loginUser("patient_bg_" + i + "_" + System.currentTimeMillis(), 
                                                 TEST_PASSWORD);
            
            int patientId = PatientDAO.createPatient(
                user.userId,
                "Blood",
                "Type" + i,
                "1990-01-01",
                "Male",
                "1234567890",
                "Test Address",
                bloodGroups[i],
                "None",
                "None"
            );
            
            PatientDAO.Patient patient = PatientDAO.getPatientById(patientId);
            assertEquals("Blood group should be " + bloodGroups[i], bloodGroups[i], patient.bloodGroup);
        }
        
        System.out.println("✅ testBloodGroupTypes PASSED");
    }
}
