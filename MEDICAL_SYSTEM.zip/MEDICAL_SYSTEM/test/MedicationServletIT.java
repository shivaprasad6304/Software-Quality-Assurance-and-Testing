/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MedicationServletIT {
    private MedicationServlet servlet;
    
    @BeforeEach
    public void setUp() {
        servlet = new MedicationServlet();
    }

    @Test
    public void testMedicationServletExists() {
        assertNotNull(servlet, "MedicationServlet should be instantiated");
    }

    @Test
    public void testMedicationServletIsNotNull() {
        MedicationServlet instance = new MedicationServlet();
        assertNotNull(instance);
    }
    
}
