package com.hospital.servlet;   // ✅ MUST match servlet package

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginServletTest {

    @Test
    public void testLoginServletExists() {
        LoginServletTest servlet = new LoginServletTest();
        assertNotNull(servlet);
        System.out.println("testLoginServletExists PASSED");
    }

    @Test
    public void testLoginServletIsNotNull() {
        LoginServletTest instance = new LoginServletTest();
        assertNotNull(instance);
        System.out.println("testLoginServletIsNotNull PASSED");
    }
}