import com.hospital.dao.UserDAO;
import com.hospital.dao.DoctorDAO;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.Statement;

import static org.junit.Assert.*;

/**
 * Integration tests for DoctorDAO - tests doctor management operations
 */
public class DoctorDAOIT extends TestBase {
    
    private int testUserId;
    private static final String TEST_USERNAME = "testdoctor_" + System.currentTimeMillis();
    private static final String TEST_PASSWORD = "TestPassword123";
    
    @Before
    public void setUp() {
        cleanUpTestData();
        
        // Create a test user to associate with doctor
        UserDAO.registerUser(TEST_USERNAME, TEST_PASSWORD, "doctor@test.com", "doctor");
        UserDAO.User user = UserDAO.loginUser(TEST_USERNAME, TEST_PASSWORD);
        testUserId = user.userId;
    }
    
    /**
     * Test: Create a doctor successfully
     */
    @Test
    public void testCreateDoctorSuccess() {
        int doctorId = DoctorDAO.createDoctor(
            testUserId,
            "Dr. John",
            "Smith",
            "Cardiology",
            "LIC001234",
            "9999999999",
            "john.smith@hospital.com"
        );
        
        assertTrue("Doctor ID should be positive", doctorId > 0);
        System.out.println("✅ testCreateDoctorSuccess PASSED - Doctor ID: " + doctorId);
    }
    
    /**
     * Test: Get doctor by ID
     */
    @Test
    public void testGetDoctorById() {
        int doctorId = DoctorDAO.createDoctor(
            testUserId,
            "Dr. Jane",
            "Doe",
            "Pediatrics",
            "LIC005678",
            "8888888888",
            "jane.doe@hospital.com"
        );
        
        DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(doctorId);
        
        assertNotNull("Doctor should be found", doctor);
        assertEquals("First name should match", "Dr. Jane", doctor.firstName);
        assertEquals("Last name should match", "Doe", doctor.lastName);
        assertEquals("Specialization should match", "Pediatrics", doctor.specialization);
        System.out.println("✅ testGetDoctorById PASSED");
    }
    
    /**
     * Test: Get doctor by user ID
     */
    @Test
    public void testGetDoctorByUserId() {
        int doctorId = DoctorDAO.createDoctor(
            testUserId,
            "Dr. Bob",
            "Johnson",
            "Orthopedics",
            "LIC009012",
            "7777777777",
            "bob.johnson@hospital.com"
        );
        
        DoctorDAO.Doctor doctor = DoctorDAO.getDoctorByUserId(testUserId);
        
        assertNotNull("Doctor should be found by user ID", doctor);
        assertEquals("User ID should match", testUserId, doctor.userId);
        System.out.println("✅ testGetDoctorByUserId PASSED");
    }
    
    /**
     * Test: Get all doctors
     */
    @Test
    public void testGetAllDoctors() {
        // Create multiple doctors
        for (int i = 0; i < 3; i++) {
            String username = "doc" + i + "_" + System.currentTimeMillis();
            UserDAO.registerUser(username, TEST_PASSWORD, "doc" + i + "@test.com", "doctor");
            UserDAO.User user = UserDAO.loginUser(username, TEST_PASSWORD);
            
            DoctorDAO.createDoctor(
                user.userId,
                "Dr. Doc" + i,
                "Name" + i,
                "Specialty" + i,
                "LIC" + String.format("%06d", i),
                "999999" + String.format("%04d", i),
                "doc" + i + "@hospital.com"
            );
        }
        
        // Get all doctors
        java.util.List<DoctorDAO.Doctor> doctors = DoctorDAO.getAllDoctors();
        
        assertNotNull("Doctor list should not be null", doctors);
        assertTrue("Should have at least 3 doctors", doctors.size() >= 3);
        System.out.println("✅ testGetAllDoctors PASSED - Total doctors: " + doctors.size());
    }
    
    /**
     * Test: Delete doctor
     */
    @Test
    public void testDeleteDoctor() {
        int doctorId = DoctorDAO.createDoctor(
            testUserId,
            "Dr. Tom",
            "Wilson",
            "Surgery",
            "LIC003456",
            "6666666666",
            "tom.wilson@hospital.com"
        );
        
        boolean result = DoctorDAO.deleteDoctor(doctorId);
        assertTrue("Delete should succeed", result);
        
        DoctorDAO.Doctor deletedDoctor = DoctorDAO.getDoctorById(doctorId);
        assertNull("Deleted doctor should not be found", deletedDoctor);
        System.out.println("✅ testDeleteDoctor PASSED");
    }
    
    /**
     * Test: Doctor specializations
     */
    @Test
    public void testDoctorSpecializations() {
        String[] specializations = {
            "Cardiology",
            "Neurology",
            "Orthopedics",
            "Pediatrics",
            "Dermatology",
            "ENT",
            "General Medicine",
            "Surgery"
        };
        
        for (int i = 0; i < specializations.length; i++) {
            String username = "spec_doc_" + i + "_" + System.currentTimeMillis();
            UserDAO.registerUser(username, TEST_PASSWORD, "spec" + i + "@test.com", "doctor");
            UserDAO.User user = UserDAO.loginUser(username, TEST_PASSWORD);
            
            int doctorId = DoctorDAO.createDoctor(
                user.userId,
                "Dr. Specialist" + i,
                "Doc" + i,
                specializations[i],
                "LIC" + String.format("%06d", 1000 + i),
                "8888888" + String.format("%03d", i),
                "spec" + i + "@hospital.com"
            );
            
            DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(doctorId);
            assertEquals("Specialization should be " + specializations[i], 
                        specializations[i], doctor.specialization);
        }
        
        System.out.println("✅ testDoctorSpecializations PASSED");
    }
    
    /**
     * Test: License number uniqueness and validation
     */
    @Test
    public void testDoctorLicenseNumbers() {
        int doctorId1 = DoctorDAO.createDoctor(
            testUserId,
            "Dr. License",
            "Test1",
            "Cardiology",
            "LIC-2024-00001",
            "5555555555",
            "license1@hospital.com"
        );
        
        DoctorDAO.Doctor doctor1 = DoctorDAO.getDoctorById(doctorId1);
        assertNotNull("Doctor should be created", doctor1);
        assertEquals("License number should match", "LIC-2024-00001", doctor1.licenseNumber);
        System.out.println("✅ testDoctorLicenseNumbers PASSED");
    }
    
    /**
     * Test: Doctor contact information
     */
    @Test
    public void testDoctorContactInfo() {
        String phone = "9876543210";
        String email = "contact.doctor@hospital.com";
        
        int doctorId = DoctorDAO.createDoctor(
            testUserId,
            "Dr. Contact",
            "Info",
            "General",
            "LIC007890",
            phone,
            email
        );
        
        DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(doctorId);
        assertEquals("Phone should match", phone, doctor.phone);
        assertEquals("Email should match", email, doctor.email);
        System.out.println("✅ testDoctorContactInfo PASSED");
    }
    
    /**
     * Test: Non-existent doctor returns null
     */
    @Test
    public void testGetNonExistentDoctor() {
        DoctorDAO.Doctor doctor = DoctorDAO.getDoctorById(99999);
        
        assertNull("Non-existent doctor should return null", doctor);
        System.out.println("✅ testGetNonExistentDoctor PASSED");
    }
}
